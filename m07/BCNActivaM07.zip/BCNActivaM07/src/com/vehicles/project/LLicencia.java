package com.vehicles.project;

public class LLicencia 
{
  protected String id;
  protected String tipus;
  protected String nomComplet;
  protected String dataCaducitat;

  public LLicencia(String id, String tipus, String nomComplet, String dataCaducitat) 
  {	this.id    = id;
	this.tipus = tipus;
	this.nomComplet = nomComplet;
	this.dataCaducitat = dataCaducitat;
   }
	  
  public String toString()
  { return "Id:"+((id==null)?"":id) + " " + 
           "Tipus:"+((tipus==null)?"":tipus) + " " +  
           "NomComplet:"+((nomComplet==null)?"":nomComplet) +" " +
           "DataCaducitat:"+((dataCaducitat==null)?"":dataCaducitat);
  }
  
}
