package com.vehicles.project;

public class Conductor extends Persona 
{ protected LLicencia llicencia;
 
  public Conductor(String nom, String cognoms, String dataNaixement,LLicencia llicencia)
  { super(nom,cognoms,dataNaixement);
	this.llicencia = llicencia;
  }

  public String toString()
  { return "Nom:"+((nom==null)?"":nom) + " " + 
           "Cognoms:"+((cognoms==null)?"":cognoms) +" " +
           "DataNaixement:"+((dataNaixement==null)?"":dataNaixement) + " " +
           "LLicencia:"+((llicencia==null)?"":llicencia.toString()) ;
  }  
}
