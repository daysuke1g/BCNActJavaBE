package com.vehicles.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Nivell2Fase3Main 
{ 
	
  public static void main(String[] args) //throws Exception
  { Titular ultimTitular = null;
	Nivell2Fase3Main objMain = new Nivell2Fase3Main();
	  
    Scanner inputScanner = new Scanner(System.in);	  

    while(true)
    { System.out.println("------------------------------------------------------------------");
      System.out.println("Sortir s/n?:"); 
      String strInput = inputScanner.nextLine();
      if(strInput.equalsIgnoreCase("S")) { break; }
    
      // Tractament del ultim titular per test ... evitar input de dades 
      Titular titular = null;
      if(ultimTitular!=null)
      { System.out.println("Arrossegar dedes ultim titular s/n?:");
        strInput = inputScanner.nextLine();
        if(strInput.equalsIgnoreCase("S")) { titular=ultimTitular; }
      }
      if(titular==null)
      { System.out.println("Introdueixi dades del titular:");
    	titular = objMain.creaTitular(inputScanner); // <<------------ Crear Titular (tambe crea la LLicencia)
        ultimTitular = titular;
      }
      
      //Sol·licitut de tipus de vehicle
      Vehicle v;
      System.out.println("Crear cotxe(c) o moto(m):"); 
      String strTipusVehicle = inputScanner.nextLine();
      try
      { 
    	if(!strTipusVehicle.equalsIgnoreCase(titular.llicencia.tipus))
    	throw new Exception("La llicencia es de tipus "+titular.llicencia.tipus+". Cal crear un vehicle de tipus "+titular.llicencia.tipus);
        
        v = objMain.crearVehicle(inputScanner,strTipusVehicle); // <<--------- Crear el vehicle
        
        System.out.println("El titular serà el conductor (s/n)?:");
        strInput = inputScanner.nextLine();
        if(strInput.equalsIgnoreCase("N"))
        { while(true)
          { System.out.println("Introdueixi dades del conductor:");
        	Conductor conductor = objMain.crearConductor(inputScanner); // <<--------- Crear conductor
        	if(strTipusVehicle.equalsIgnoreCase(conductor.llicencia.tipus))
        	{ break;
        	}
        	else
        	{ System.out.println("La llicencia del conductor no li permet conduir el vehicle ("+strTipusVehicle+")");
        		
        	}
        	
          }
        }
        
      }
      catch(Exception ex)
      { System.out.println(ex.getMessage());
      }
      
    }

    inputScanner.close();
    System.out.println("Fin");
  } // end main
 	
  
  public Titular creaTitular(Scanner inputScanner)
  { Titular titular = null;
	  
    System.out.println("TITULAR Introdueixi nom:");    String strNom     = inputScanner.nextLine();
    System.out.println("TITULAR Introdueixi Cognoms:");String strCognoms = inputScanner.nextLine();
    System.out.println("TITULAR Introdueixi Data Naixement:");String strDataNaix = inputScanner.nextLine();
    System.out.println("TITULAR Te segur (t/f)?:");         String strTeSegur = inputScanner.nextLine();
    System.out.println("TITULAR Te aparcament (t/f)?:");    String strTeAparcament = inputScanner.nextLine();
    
    boolean bTeSegur      = strTeSegur.equalsIgnoreCase("t");
    boolean bTeAparcament = strTeAparcament.equalsIgnoreCase("t");
    
    LLicencia llicencia = creaLLicencia(inputScanner,(strNom+" "+strCognoms));
    titular = new Titular(strNom,strCognoms,strDataNaix,llicencia,bTeSegur,bTeAparcament);
     
	return titular;  
  } // end public Titular creaTitular(Scanner inputScanner)
  
  
  public LLicencia creaLLicencia(Scanner inputScanner,String nomComplet)
  { LLicencia llicencia = null;
    System.out.println("LLICENCIA Introdueixi Id:");    String strId     = inputScanner.nextLine();
    System.out.println("LLICENCIA Introdueixi Tipus(C/M):");String strTipus = inputScanner.nextLine();
    System.out.println("LLICENCIA Introdueixi Data Caducitat:"); String strDataCaduca = inputScanner.nextLine();
    strTipus = strTipus.toUpperCase();
    llicencia = new LLicencia(strId,strTipus,nomComplet,strDataCaduca);     
    return llicencia;
  }
  
  public Vehicle crearVehicle(Scanner inputScanner,String tipusVehicle) throws Exception
  { Vehicle v = null;
	
    /*
     CREO DIRECTAMENT PER EVITAR INPUTS DE PANTALLA AL TESTEJAR 
    */
    if (tipusVehicle.equalsIgnoreCase("C")) //--Crear cotxe 
    { Car vCar = new Car("1234HJK","Seat","Blau");      
      Wheel wp = new Wheel("Michelin",3.9);
      List<Wheel> backWheels = new ArrayList<>();
      backWheels.add(wp);
      backWheels.add(wp);
      Wheel wa = new Wheel("Michelin",3);
      List<Wheel> frontWheels = new ArrayList<>();
      frontWheels.add(wa);
      frontWheels.add(wa);
      vCar.addWheels(frontWheels,backWheels); 
      v = vCar;
    }
    else if (tipusVehicle.equalsIgnoreCase("M")) //Crear Bike
    { Bike vBike  = new Bike("5678HJK","Honda","Negra");    
      Wheel wp = new Wheel("Michelin",2);
      List<Wheel> backWheels = new ArrayList<>();
      backWheels.add(wp);
      Wheel wa = new Wheel("Michelin",1);
      List<Wheel> frontWheels = new ArrayList<>();
      frontWheels.add(wa);
      vBike.addWheels(frontWheels,backWheels);
      v = vBike;
    }
	return v;
  }
  
  public Conductor crearConductor(Scanner inputScanner)
  { Conductor conductor = null; 
     
    System.out.println("CONDUCTOR Introdueixi nom:");    String strNom     = inputScanner.nextLine();
    System.out.println("CONDUCTOR Introdueixi Cognoms:");String strCognoms = inputScanner.nextLine();
    System.out.println("CONDUCTOR Introdueixi Data Naixement:");String strDataNaix = inputScanner.nextLine();
  
    LLicencia llicencia = creaLLicencia(inputScanner,(strNom+" "+strCognoms));
    conductor = new Conductor(strNom,strCognoms,strDataNaix,llicencia);
   
	return conductor;  
  }
  
  
}
