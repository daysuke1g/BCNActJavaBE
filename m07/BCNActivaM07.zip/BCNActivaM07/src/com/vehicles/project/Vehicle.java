package com.vehicles.project;

import java.util.ArrayList;
import java.util.List;

public abstract class Vehicle 
{
  protected String plate;
  protected String brand;
  protected String color;
  protected List<Wheel> wheels = new ArrayList<Wheel>();
  
  protected Titular titular;
  protected ArrayList<Conductor> mAlConductors  = null;

  public Vehicle(String plate, String brand, String color) throws Exception 
  {	setplate(plate);
    this.brand = brand;
    this.color = color;
  }
    
  public void setplate(String plate) throws Exception //throws Exception
  { String msgEx = "Una matr�cula ha de tenir 4 n�meros i dues o tres lletres.";
	  
	int lengthPlate = plate.length();
	if((lengthPlate!=6)&&(lengthPlate!=7)) { throw new Exception(msgEx); }
    if(!plate.substring(0,4).matches("[0-9]+")) { throw new Exception(msgEx); }    
    if(!plate.substring(4,lengthPlate).toUpperCase().matches("[A-Z]+")) { throw new Exception(msgEx); }  
		
	this.plate = plate; 
	
	mAlConductors = new ArrayList<Conductor>();
  }
 
  public String toString()
  { String strConductors = "";
    for(Conductor c:mAlConductors)
    { String strC = c.toString();
      if(strC!=null)
      { strConductors += " Conductor " + strC;
      }
    }
    
    return "Plate:"+((plate==null)?"":plate) + " " + 
           "Brand:"+((brand==null)?"":brand) + " " +  
           "Color:"+((color==null)?"":color) + " " + 
           " ---- Titular:"+((titular==null)?"":titular.toString() + " "+
           " ---- Conductors:"+strConductors) ;
  }  
    
  public Titular getTitular()          { return titular; }
  public void    setTitular(Titular t) { titular = t; }

  public List<Conductor> getConductors() { return mAlConductors; }
  public void addConductor(Conductor c) { mAlConductors.add(c); }
    
  
}


