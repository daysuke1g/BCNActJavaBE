package com.vehicles.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Nivell1Fase1Main 
{
  public static void main(String[] args)
  {
    Scanner inputScanner = new Scanner(System.in);	  

    //Sol�licitut de parametres
    System.out.println("Introdueixi matr�cula:"); 
    String strMatricula = inputScanner.nextLine();
    System.out.println("Introdueixi marca:"); 
    String strMarca = inputScanner.nextLine();
    System.out.println("Introdueixi color:"); 
    String strColor = inputScanner.nextLine();
        
    try
    { 
      Car c = new Car(strMatricula,strMarca,strColor);//Crear cotxe
        
      //Sol�licitut de parametres pneumatics posteriors.  
      System.out.println("Introdueixi marca dels pneumatics posteriors:"); 
      String strMarcaRodesPost = inputScanner.nextLine();
      System.out.println("Introdueixi diametres dels pneumatics posteriors(n�meric):"); 
      String diametrePosterior = inputScanner.nextLine();
      double dimPost = Double.parseDouble(diametrePosterior);
    	
      //Crear la llista amb les rodes posteriors    
      Wheel wp = new Wheel(strMarcaRodesPost,dimPost);
      List<Wheel> backWheels = new ArrayList<>();
      backWheels.add(wp);
      backWheels.add(wp);
    
      //Sol�licitut de parametres pneumatics anteriors 
      System.out.println("Introdueixi marca dels pneumatics anteriors:"); 
      String strMarcaRodesAnt = inputScanner.nextLine();
      System.out.println("Introdueixi diametres dels pneumatics anteriors(n�meric):"); 
      String diametreAnterior = inputScanner.nextLine();  
      double dimAnt = Double.parseDouble(diametreAnterior);
    
      //Crear la llista amb les rodes anteriors
      Wheel wa = new Wheel(strMarcaRodesAnt,dimAnt);
      List<Wheel> frontWheels = new ArrayList<>();
      frontWheels.add(wa);
      frontWheels.add(wa);

      c.addWheels(frontWheels,backWheels);
    }
    catch(Exception ex)
    { ex.printStackTrace();
    	
    }
 
    inputScanner.close();
    System.out.println("Fin");
  }
 	
}
