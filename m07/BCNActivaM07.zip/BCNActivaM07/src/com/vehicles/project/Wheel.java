package com.vehicles.project;

public class Wheel 
{ private String brand;
  private double diameter;

  public Wheel(String brand, double diameter) throws Exception 
  { this.brand = brand;
    setDiameter(diameter);    
  }
  
  public void setDiameter(double diameter) throws Exception
  { if( (diameter>0.4) && (diameter<4) ) { this.diameter = diameter; } 
      else { throw new Exception("Diametre incorrecte (>0.4 y < 4)."); }
  }
  
  
  
}

