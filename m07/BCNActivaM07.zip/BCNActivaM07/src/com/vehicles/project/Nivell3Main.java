package com.vehicles.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Nivell3Main 
{ 
  Scanner            inputScanner = null;	  	
  ArrayList<Persona> mAlPersones  = null; 
  ArrayList<Vehicle> mAlVehicles  = null;
  
  public static void main(String[] args) //throws Exception
  { 
    Nivell3Main objMain = new Nivell3Main();
    objMain.runApp();
	
  } // end main
  
  
  public Nivell3Main()
  { inputScanner = new Scanner(System.in);
    mAlPersones  = new ArrayList<>();
    mAlVehicles  = new ArrayList<>();
  }
  
  private void exitApp()
  { if(inputScanner!=null) { inputScanner.close(); }	 
    if(mAlPersones!=null)  { mAlPersones.clear(); }
    if(mAlVehicles!=null)  { mAlVehicles.clear(); } 
  }
  
  public void runApp()
  { 
    initTitularsYConductors();
  
    boolean bSalir=false;
    while(!bSalir)
    { System.out.println("------------------------------------------------------------------------");
      System.out.println("Menu principal esculli  opció:"); 
      System.out.println("1-Sortir");
      System.out.println("2-Menu Persones");
      System.out.println("3-Menu Vehicles");
      String strInput = inputScanner.nextLine();
      switch(strInput)
      { case "1": { bSalir=true; break; }
        case "2": { menuPersones(); break; }
        case "3": 
        { if(!existeixenTitulars()) { System.out.println("No hi han titulars definits encara. No es poden crear vehicles."); }
            else { menuVehicles(); }
          break; 
        }
      }
    } //end while
    exitApp();
  } // end  public void runApp()
  
  private void menuPersones()
  { boolean bSalir=false;
    while(!bSalir)
    { System.out.println("Menu persones esculli  opció:"); 
      System.out.println("1-Sortir");
      System.out.println("2-Crear titular");
      System.out.println("3-Crear conductor");
      System.out.println("7-Mostrar totes les persones");
      System.out.println("8-Mostrar titulars");
      System.out.println("9-Mostrar conductors (no titulars)");
      String strInput = inputScanner.nextLine();
      switch(strInput)
      { case "1": { bSalir=true; break; }
        case "2": 
        { Titular t = creaTitular(inputScanner);
          if(t!=null) { mAlPersones.add(t) ; }
          break;
        }        
        case "3": 
        { Conductor c = creaConductor(inputScanner);        
          if(c!=null) { mAlPersones.add(c) ; }
          break;
        }
        case "7": { mostrarPersona(null); break; }
        case "8": { mostrarPersona("T"); break; }
        case "9": { mostrarPersona("C"); break; }
      }	  
    }
  }
  
  private void menuVehicles()
  { boolean bSalir=false;
	while(!bSalir)
	{ System.out.println("Menu persones esculli  opció:"); 
	  System.out.println("1-Sortir");
	  System.out.println("2-Crear vehicle");
	  System.out.println("9-Mostrar vehicles");
	  String strInput = inputScanner.nextLine();
	  switch(strInput)
	  { case "1": { bSalir=true; break; }
	    case "2": 
	    { System.out.println("Crear cotxe(C) o moto(m)?:");
          strInput = inputScanner.nextLine();
          strInput = strInput.toUpperCase();
          if( (strInput.equalsIgnoreCase("C")) || (strInput.equalsIgnoreCase("M")) ) 
          { try 
            { Vehicle v = creaVehicle(inputScanner,strInput);
              if(v!=null) { mAlVehicles.add(v) ; }
            }
            catch(Exception ex) { System.out.println("ERROR : "+ex.getMessage()); }           
          }
          else 
          { System.out.println("Tipus de vehicle no reconegut");  
          }
          break;
        }
	    case "9":  { mostrarVehicles(); break; }
      }	 
    }	  
  }
  
  private Titular creaTitular(Scanner inputScanner)
  { Titular titular = null;
	  
    System.out.println("TITULAR Introdueixi nom:");    String strNom     = inputScanner.nextLine();
    System.out.println("TITULAR Introdueixi Cognoms:");String strCognoms = inputScanner.nextLine();
    System.out.println("TITULAR Introdueixi Data Naixement:");String strDataNaix = inputScanner.nextLine();
    System.out.println("TITULAR Te segur (t/f)?:");         String strTeSegur = inputScanner.nextLine();
    System.out.println("TITULAR Te aparcament (t/f)?:");    String strTeAparcament = inputScanner.nextLine();
    
    boolean bTeSegur      = strTeSegur.equalsIgnoreCase("t");
    boolean bTeAparcament = strTeAparcament.equalsIgnoreCase("t");
    
    LLicencia llicencia = creaLLicencia(inputScanner,(strNom+" "+strCognoms));
    titular = new Titular(strNom,strCognoms,strDataNaix,llicencia,bTeSegur,bTeAparcament);
     
	return titular;  
  } // end public Titular creaTitular(Scanner inputScanner)
  
  
  private LLicencia creaLLicencia(Scanner inputScanner,String nomComplet)
  { LLicencia llicencia = null;
    System.out.println("LLICENCIA Introdueixi Id:");    String strId     = inputScanner.nextLine();
    System.out.println("LLICENCIA Introdueixi Tipus(C/M):");String strTipus = inputScanner.nextLine();
    System.out.println("LLICENCIA Introdueixi Data Caducitat:"); String strDataCaduca = inputScanner.nextLine();
    strTipus = strTipus.toUpperCase();
    llicencia = new LLicencia(strId,strTipus,nomComplet,strDataCaduca);     
    return llicencia;
  }
  
  private Vehicle creaVehicle(Scanner inputScanner,String tipusVehicle) throws Exception
  { Vehicle v = null;
	
    if(!existeixTitularPerTipusVehicles(tipusVehicle))
    { throw new Exception("No hi han conductors de tipus " +  tipusVehicle);
    }
  
    System.out.println("Introdueixi nom titular:");
    String strInput = inputScanner.nextLine();
    Titular titular = getTitularByName(strInput);
    if(titular==null)
    { throw new Exception("No hi ha cap titular amb aqust nom");      
    }
        
    /*
     CREO DIRECTAMENT PER EVITAR INPUTS DE PANTALLA AL TESTEJAR 
    */
    if (tipusVehicle.equalsIgnoreCase("C")) //--Crear cotxe 
    { Car vCar = new Car("1234HJK","Seat","Blau");      
      Wheel wp = new Wheel("Michelin",3.9);
      List<Wheel> backWheels = new ArrayList<>();
      backWheels.add(wp);
      backWheels.add(wp);
      Wheel wa = new Wheel("Michelin",3);
      List<Wheel> frontWheels = new ArrayList<>();
      frontWheels.add(wa);
      frontWheels.add(wa);
      vCar.addWheels(frontWheels,backWheels); 
      v = vCar;
    }
    else if (tipusVehicle.equalsIgnoreCase("M")) //Crear Bike
    { Bike vBike  = new Bike("5678HJK","Honda","Negra");    
      Wheel wp = new Wheel("Michelin",2);
      List<Wheel> backWheels = new ArrayList<>();
      backWheels.add(wp);
      Wheel wa = new Wheel("Michelin",1);
      List<Wheel> frontWheels = new ArrayList<>();
      frontWheels.add(wa);
      vBike.addWheels(frontWheels,backWheels);
      v = vBike;
    }    
    v.setTitular(titular);
    
    afegirConductors(v,inputScanner);
    
  	return v;
  }
  
  private Conductor creaConductor(Scanner inputScanner)
  { Conductor conductor = null; 
     
    System.out.println("CONDUCTOR Introdueixi nom:");    String strNom     = inputScanner.nextLine();
    System.out.println("CONDUCTOR Introdueixi Cognoms:");String strCognoms = inputScanner.nextLine();
    System.out.println("CONDUCTOR Introdueixi Data Naixement:");String strDataNaix = inputScanner.nextLine();
  
    LLicencia llicencia = creaLLicencia(inputScanner,(strNom+" "+strCognoms));
    conductor = new Conductor(strNom,strCognoms,strDataNaix,llicencia);
   
	return conductor;  
  }
  
  private void  mostrarPersona(String pTipus)
  { if(mAlPersones!=null)
    { for(Persona p:mAlPersones)
      { // java com.vehicles.project.Nivell3Main
    	  if(pTipus!=null)
    	  { if     ( pTipus.equalsIgnoreCase("T") && (p instanceof com.vehicles.project.Titular) )
    	    { System.out.println("Classe " + p.getClass().getCanonicalName()+":"+p.toString());   
          }
    	    else if( pTipus.equalsIgnoreCase("C") && (p instanceof com.vehicles.project.Conductor) && 
    	             p.getClass().getCanonicalName().equalsIgnoreCase("com.vehicles.project.Conductor") )
    	    { System.out.println("Classe " + p.getClass().getCanonicalName()+":"+p.toString());
    	    }
    	  }
    	  else
    	  { System.out.println("Classe " + p.getClass().getCanonicalName()+":"+p.toString());    		
       	}
      }
    }
  }
  
  private void mostrarVehicles()
  { if(mAlVehicles!=null)
    { for(Vehicle v:mAlVehicles)
      { System.out.println("Vehicle:"+v.toString());
      }
    }
  }
  
  private boolean existeixenTitulars()
  { if(mAlPersones==null) { return false; }
    for(Persona p:mAlPersones)
    { if( p instanceof com.vehicles.project.Titular )
      { return true;
      }
    }
    return false;
  }
  
  private boolean existeixTitularPerTipusVehicles(String tipusVehicle)
  { if(mAlPersones!=null)
    { for(Persona p:mAlPersones)
      { if(p instanceof Conductor)
        { Conductor c = (Conductor) p;
          if(c.llicencia.tipus.equalsIgnoreCase(tipusVehicle)) { return true; }      	  
        }
      }
    }
    return false;
  }
  
  private Titular getTitularByName(String nom)
  { if(mAlPersones!=null)
    { for(Persona p:mAlPersones)
      { if(p instanceof Titular)
        { if(p.nom.equalsIgnoreCase(nom)) 
          { return (Titular)p;
          }
        }
      }
    }
    return null;
  }
  
  private Conductor getConductorByName(String nom)
  { if(mAlPersones!=null)
    { for(Persona p:mAlPersones)
      { if(p instanceof Conductor)
        { if(p.nom.equalsIgnoreCase(nom)) 
          { return (Conductor)p;
          }
        }
      }
    }
    return null;
  }
  
  private void afegirConductors(Vehicle v,Scanner inputScanner)
  { while(true)
    { System.out.println("Afegir conductors. Introdueixi el nom del conductor o 's' per sortir");
      String strInput = inputScanner.nextLine();
      if(strInput.equalsIgnoreCase("s")) { break; }
      Conductor conductor = getConductorByName(strInput);
      if(conductor!=null) 
      { if( ( (conductor.llicencia.tipus.equalsIgnoreCase("C")) && (v instanceof com.vehicles.project.Car) ) ||
            ( (conductor.llicencia.tipus.equalsIgnoreCase("M")) && (v instanceof com.vehicles.project.Bike) ) )
        { v.addConductor(conductor);
        }
        else
        { System.out.println("La llicencia d'aqest conductor no permet conduir aquest vehicle."); 
        }
      }
      else { System.out.println("No s'ha trobat cap conductor amb aquest nom."); }
    }        
  }
  
  
  private void initTitularsYConductors()
  {
    LLicencia llicencia1 = new LLicencia("IDC01","C","Nom complet titular llicencia IDC01","31/12/2021");     
    LLicencia llicencia2 = new LLicencia("IDC02","C","Nom complet titular llicencia IDC02","31/12/2022");     
    LLicencia llicencia3 = new LLicencia("IDC03","C","Nom complet titular llicencia IDC03","31/12/2023");     
    LLicencia llicencia4 = new LLicencia("IDC04","M","Nom complet titular llicencia IDC04","31/12/2024");     
    LLicencia llicencia5 = new LLicencia("IDC05","M","Nom complet titular llicencia IDC05","31/12/2025");     
    
    Titular titular1 = new Titular("Nom Titular1","Cognoms Titular1","01/01/1973",llicencia1,true,true);
    Titular titular2 = new Titular("Nom Titular2","Cognoms Titular2","01/01/1974",llicencia2,true,true);
    Titular titular3 = new Titular("Nom Titular3","Cognoms Titular3","01/01/1975",llicencia3,true,true);
    Titular titular4 = new Titular("Nom Titular4","Cognoms Titular4","01/01/1976",llicencia4,true,true);
    Titular titular5 = new Titular("Nom Titular5","Cognoms Titular5","01/01/1977",llicencia5,true,true);

    mAlPersones.add(titular1); 
    mAlPersones.add(titular2);
    mAlPersones.add(titular3);
    mAlPersones.add(titular4);
    mAlPersones.add(titular5);

    LLicencia llicencia6 = new LLicencia("IDC06","C","Nom complet titular llicencia IDC06","31/12/2021");     
    LLicencia llicencia7 = new LLicencia("IDC07","C","Nom complet titular llicencia IDC07","31/12/2022");     
    LLicencia llicencia8 = new LLicencia("IDC07","C","Nom complet titular llicencia IDC08","31/12/2023");     
    LLicencia llicencia9 = new LLicencia("IDC08","M","Nom complet titular llicencia IDC09","31/12/2024");     
    LLicencia llicencia0 = new LLicencia("IDC00","M","Nom complet titular llicencia IDC00","31/12/2025");
    
    Conductor conductor1 = new Conductor("Nom Conductor1","Cognoms Conductor1","01/01/1978",llicencia6);
    Conductor conductor2 = new Conductor("Nom Conductor2","Cognoms Conductor2","01/01/1979",llicencia7);
    Conductor conductor3 = new Conductor("Nom Conductor3","Cognoms Conductor3","01/01/1980",llicencia8);
    Conductor conductor4 = new Conductor("Nom Conductor4","Cognoms Conductor4","01/01/1981",llicencia9);
    Conductor conductor5 = new Conductor("Nom Conductor5","Cognoms Conductor5","01/01/1982",llicencia0);
    
    mAlPersones.add(conductor1); 
    mAlPersones.add(conductor2); 
    mAlPersones.add(conductor3); 
    mAlPersones.add(conductor4); 
    mAlPersones.add(conductor5); 
    
  }
  
  
}
