package com.vehicles.project;

public class Titular extends Conductor 
{
  protected boolean teSegur;
  protected boolean teAparcament;
	 
  public Titular(String nom, String cognoms, String dataNaixement,LLicencia llicencia,boolean teSegur,boolean teAparcament)
  { super(nom,cognoms,dataNaixement,llicencia);
	this.teSegur = teSegur;
	this.teAparcament = teAparcament;
  }
  
  public String toString()
  { return "Nom:"+((nom==null)?"":nom) + " " + 
           "Cognoms:"+((cognoms==null)?"":cognoms) +" " +
           "DataNaixement:"+((dataNaixement==null)?"":dataNaixement) + " " +
           "TeSegur:"+teSegur+ " " +
           "TeAparcament:"+teAparcament+ " " +
           "LLicencia:"+((llicencia==null)?"":llicencia.toString()) ;
  }
  
}
