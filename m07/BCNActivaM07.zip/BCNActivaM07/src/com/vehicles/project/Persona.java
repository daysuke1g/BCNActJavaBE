package com.vehicles.project;

public class Persona 
{
  protected String nom;
  protected String cognoms;
  protected String dataNaixement;

  public Persona(String nom, String cognoms, String dataNaixement) 
  {	this.nom     = nom;
    this.cognoms = cognoms;
    this.dataNaixement = dataNaixement;
  }
    
}