package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.vehicles.project.Car;

class Nivell2Test 
{
  public static void main(String[] args) 
  { Car c ;
	try 
	{ c = new Car("0000A","Seat","Blau"); 
	  System.out.println("Fin");
	}
	catch(Exception ex) { ex.printStackTrace(); }
	
  }
	
	
  @Test
  void testMatricula() 
  { Car car ; 
	Exception exception;
    String msgException = "Una matr�cula ha de tenir 4 n�meros i dues o tres lletres.";
    //-- Test Longitud incorrecta 
    exception = assertThrows(Exception.class,() -> { Car c = new Car("0000A","Seat","Blau");  } ) ;
    assertEquals(msgException,exception.getMessage());
    exception = assertThrows(Exception.class,() -> { Car c = new Car("0000AAAA","Seat","Blau");  } ) ;
    assertEquals(msgException,exception.getMessage());
    //-- Test Format Incorrrecte 
    exception = assertThrows(Exception.class,() -> { Car c = new Car("AAAAAAA","Seat","Blau");  } ) ;
    assertEquals(msgException,exception.getMessage());    
    exception = assertThrows(Exception.class,() -> { Car c = new Car("000AAAA","Seat","Blau");  } ) ;
    assertEquals(msgException,exception.getMessage());
    exception = assertThrows(Exception.class,() -> { Car c = new Car("00000AA","Seat","Blau");  } ) ;
    assertEquals(msgException,exception.getMessage());
    //-- Test Format Correcte
    assertDoesNotThrow( () -> { Car c = new Car("1234AB","Seat","Blau"); } );
    assertDoesNotThrow( () -> { Car c = new Car("0000AAA","Seat","Blau"); } );
    assertDoesNotThrow( () -> { Car c = new Car("1234ABC","Seat","Blau"); } );
    
  }
  
}
