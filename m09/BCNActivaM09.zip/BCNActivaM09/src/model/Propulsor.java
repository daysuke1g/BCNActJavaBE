package model;

public class Propulsor
{ private static int mNumeradorPropulsor = 1;
  
  private   int idPropulsor = 0; 
  protected int potenciaMaxima;
  protected int potenciaActual;
  protected int potenciaObjectiu;

  public Propulsor(int potenciaMaxima,int potenciaObjectiu) 
  { 
    // un ltre opcio seria tenir a nivell de classe 
    // private static java.util.concurrent.atomic.AtomicInteger mAtomicInteger = new java.util.concurrent.atomic.AtomicInteger();
    // i aqui en el constructor agafar numerador e incrementar com this.idPropulsor = mAtomicInteger.getAndIncrement()
    synchronized(Propulsor.class) // sincronitzacion per acces concurrent
    { this.idPropulsor = mNumeradorPropulsor++;  
    }
    setPotenciaMaxima(potenciaMaxima);
    setPotenciaObjectiu(potenciaObjectiu);
    potenciaActual = 0; // Inicialment a 0. Aturat
  }
  
  
  public void accelerar()
  { if(potenciaActual==potenciaObjectiu) { return; } 
    if(potenciaActual<potenciaObjectiu)  { potenciaActual++; }
  }
     
  public void frenar()
  { if(potenciaActual==potenciaObjectiu) { return; } 
    if(potenciaActual>potenciaObjectiu)  { potenciaActual--; }
  }
    
  // -- Getters
  public int getPotenciaMaxima() {  return potenciaMaxima; }

  public int getPotenciaActual() {  return potenciaActual; }
  
  public int getPotenciaObjectiu() { return potenciaObjectiu; }
  
  //Setters 

  public void setPotenciaMaxima(int potenciaMaxima) {
    this.potenciaMaxima = potenciaMaxima;
  }
  
  public void setPotenciaObjectiu(int potenciaObjectiu) 
  { if(potenciaObjectiu>potenciaMaxima) { potenciaObjectiu = potenciaMaxima; } //Com a molt la maxima 
    else if(potenciaObjectiu<0)         { potenciaObjectiu = 0; } //Com a poc la minima potencia es 0
    this.potenciaObjectiu = potenciaObjectiu;
  }
  
  public void setPotenciaActual(int potenciaActual) 
  { if(potenciaActual>potenciaMaxima) { potenciaActual = potenciaMaxima; } //Com a molt la maxima 
    else if(potenciaActual<0)         { potenciaActual = 0; } //Com a poc la minima potencia es 0
    this.potenciaActual = potenciaActual;
  }  
  
  @Override
  public String toString() {
    return "Propulsor [IdPropulsor="+idPropulsor+", potenciaMaxima=" + potenciaMaxima + ", "+
                      "potenciaActual=" + potenciaActual + ", potenciaObjectiu=" + potenciaObjectiu + "]";
  }
  
}
