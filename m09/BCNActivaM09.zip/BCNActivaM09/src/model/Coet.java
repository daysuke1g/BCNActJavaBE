package model;

import java.util.List;

public class Coet 
{
  protected String id;
  protected int velocitat;
  protected List<Propulsor> lPropulsors;
  
  
  public Coet(String id,int velocitat, List<Propulsor> lPropulsors) 
  { //super();
    this.id = id;
    this.velocitat = velocitat;
    this.lPropulsors = lPropulsors;
  }

  /**
   * Recorre la llista de propulsors del coet i per cada un estableix el
   * la potencia objetiu en base al % de potencia desitjada. Aixi per exemple
   * Si un coet te dos propulsors, un de potencia maxima 100 i l'altre 50 i
   * es demana que operin al 50%, el primer la potencia objectiu ser� 50 i pel
   * segon 25      
   * @throws Exception 
   */
  public void setPercentagePotenciaObjectiuPropulsors(int pTPCPotencia) throws Exception
  { if ( (pTPCPotencia<0) || (pTPCPotencia>100) ) { throw new Exception("La potencia ha d'estar entre 0 i 100."); } 
    for(Propulsor p : lPropulsors)
    { p.setPotenciaObjectiu( (p.getPotenciaMaxima()*pTPCPotencia)/100 );      
    }
  }
  
  /**
   * Recorre la llista de propulsors del coet i per cada un estableix el
   * la potencia actual en base al % de potencia desitjada. Aixi per exemple
   * Si un coet te dos propulsors, un de potencia maxima 100 i l'altre 50 i
   * es demana que operin al 50%, el primer la potencia objectiu ser� 50 i pel
   * segon 25       
   */
  public void setPercentagePotenciaActualPropulsors(int pTPCPotencia) throws Exception
  { if ( (pTPCPotencia<0) || (pTPCPotencia>100) ) { throw new Exception("La potencia ha d'estar entre 0 i 100."); } 
    for(Propulsor p : lPropulsors)
    { p.setPotenciaActual( (p.getPotenciaMaxima()*pTPCPotencia)/100 );      
    }
  }
  
  public List<Propulsor> getPropulsors() {
    return lPropulsors;
  }

  public void setNumPropulsors(List<Propulsor> lPropulsors) {
    this.lPropulsors = lPropulsors;
  }

  public String getId() {
    return id;
  }
  
  public int getVelocitat() {
    return velocitat;
  }

  public void setVelocitat(int pVelocitat) {
    if(pVelocitat<0) { pVelocitat = 0; }
    this.velocitat = velocitat;
  }

  @Override
  public String toString() 
  { String strPropulsors = "Populsors : [ ";
    for(Propulsor p:lPropulsors)
    { strPropulsors += p.toString() + " , ";
    }
    strPropulsors += "]";
    
    return "Rocket id=" + id + " " + strPropulsors;
  }  
  
  
  /**
   * Calcula la potencia aportada pel motors treballant tots ells a un cert percentage de potencia
   * @param pTPC
   * @return
   * @throws Exception 
   */
  public int getPotenciaPropulsorsTPC(int pTPC) throws Exception
  { int dSumaPot = 0; 
    
    if((pTPC<0)||(pTPC>100)) { throw new Exception("Els propulsors han de treballar entre el 0% i el 100 % de potencia."); }
    if(pTPC==0) { return dSumaPot; } 
    for(Propulsor p : lPropulsors)
    { int dPotTPC = ( p.getPotenciaMaxima() * pTPC ) / 100; // Potencia aportada pel propulsor treballan a cert %
      dSumaPot += dPotTPC;
    }  
    return dSumaPot;
  }
  
  
  
}
