package controller;

import model.Propulsor;

public class Nivell1ThreadSincronitzaPropulsor implements Runnable
{ private   long      defSleepInMillis;     
  protected String    idCoet;
  protected Propulsor propulsor; 
  
  public Nivell1ThreadSincronitzaPropulsor(String pIdCoet,Propulsor p)
  { idCoet = pIdCoet;
    propulsor = p;
    defSleepInMillis = 300;
  }
  
  public void run()
  { 
    Thread currentThread = Thread.currentThread();
    String szMsg = "Thread name " + currentThread.getName() +" "+
                   "Thread id " + currentThread.getId() +" " + 
                   "Inici sincronitzacio coet " + idCoet + " Propulsor " + propulsor.toString();
    System.out.println(szMsg);
    while(true)
    { int dPotObjectiu = propulsor.getPotenciaObjectiu();
      int dPotActual   = propulsor.getPotenciaActual();
      if(dPotObjectiu==dPotActual) { break; } // <--- Finalitzacio: Pot Actual == pot Objectiu 
      if(dPotActual<dPotObjectiu) { propulsor.accelerar(); } // <---- Accelerar  
          else { propulsor.frenar(); } // <-------------------------- Frenar
      szMsg = "Thread name " + currentThread.getName() +" "+
                     "Thread id " + currentThread.getId() +" " + 
                     "Sincronitzant Coet " + idCoet + " Propulsor " + propulsor.toString();
      System.out.println(szMsg);
      try { currentThread.sleep(defSleepInMillis);  }
      catch (InterruptedException e) { e.printStackTrace(); }
    }
    szMsg = "___PROPULSOR SINCRONITZAT Thread name " + currentThread.getName() +" "+
            "Thread id " + currentThread.getId() +" " + 
            "Sincronitzat!!! Coet " + idCoet + " Propulsor " + propulsor.toString();
    System.out.println(szMsg);    
  }
  
  
}
