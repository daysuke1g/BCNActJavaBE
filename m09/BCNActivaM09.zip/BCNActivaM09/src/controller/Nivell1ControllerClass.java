package controller;

import java.util.List;

import model.Coet;
import model.Propulsor;

public class Nivell1ControllerClass 
{
  
  List<Coet> mLCoets = new java.util.ArrayList<Coet>();
  
  public Nivell1ControllerClass()
  {
    
  }
  
  public boolean afegeixCoet(Coet c)
  { return mLCoets.add(c);
  }

  /**
   * Obte el coet, i ajusta el % de potencia del seus propulsors
   * @param pIdCoet
   * @param i
   * @throws Exception
   */
  public void setPercentatgePotenciaCoet(String pIdCoet, int pTPCPotencia) throws Exception 
  { Coet c = getCoet(pIdCoet);
    if(c==null) { throw new Exception("Coet inexistent."); }
       else { c.setPercentagePotenciaObjectiuPropulsors(pTPCPotencia); }     
  }

  /**
   * Obte el coet i estableix la potencia actual com un % de la potencia del coet 
   * @param pIdCoet
   * @param pTPCPotencia
   * @throws Exception
   */
  public void setPercentatgePotenciaActual(String pIdCoet, int pTPCPotencia) throws Exception 
  { Coet c = getCoet(pIdCoet);
    if(c==null) { throw new Exception("Coet inexistent."); }
       else { c.setPercentagePotenciaActualPropulsors(pTPCPotencia); }     
  }  
  
  /**
   * Retorna el coet de la llista de coets amb el Id pasat per param
   * @param pIdCoet
   * @return
   */
  public Coet getCoet(String pIdCoet)
  { Coet cOut = null;
    for(Coet c:mLCoets) // Buscar el coet
    { if(c.getId().equalsIgnoreCase(pIdCoet))
      { cOut = c;
        break;
      }     
    }  
    return cOut;  
  }
  
  /**
   * Sincronitza les potencies dels propulsors d'un coet. Al final del metode tots el propulsors del coet
   * han de tenir la potencia actual a la potencia objectiu. L'ajust es propdueix en Threads separats.
   * @param pIdCoet
   */
  public void sincronitzaPotencia(String pIdCoet) 
  { Coet coetAsincronitzar = getCoet(pIdCoet);
    if(coetAsincronitzar!=null) // si trobat 
    { List<Propulsor> lPropulsors = coetAsincronitzar.getPropulsors(); // obtenir llista de propulsors
      if(lPropulsors.size()>0) // si hi al menys 1 
      { Thread[] arrThreads = new Thread[lPropulsors.size()]; // Crear una llista de Threads (1 Propulsor -> 1 Thread)
        for(int dIdx=0;dIdx<lPropulsors.size();dIdx++) // Cada Thread amb un runnable Nivell1ThreadSincronitzaPropulsor
        { arrThreads[dIdx] = new Thread(new Nivell1ThreadSincronitzaPropulsor(coetAsincronitzar.getId(),lPropulsors.get(dIdx)));
        }
        //Arrancar cada un dels fils 
        for(int dIdx=0;dIdx<arrThreads.length;dIdx++)
        { arrThreads[dIdx].start();
        }
        // Esperar que tots els fils acabin ... barrier syncrhonization
        for(int dIdx=0;dIdx<arrThreads.length;dIdx++)
        { try { arrThreads[dIdx].join(); } 
          catch (InterruptedException e) { e.printStackTrace(); }
        }        
      }
    }
    System.out.println("Sincronitzaci� de potencies de propulsors per al coet "+pIdCoet+" finalitzada");
  }

  /**
   * Retorna el % al que han d'operar el propulsors del coet pIdCoet per a obtenir la velocitat 
   * pVelocitatObjectiu. Si no ho poden aconsseguir llan�a una exepci�
   * @param pIdCoet
   * @param pVelocitatObjectiu
   * @return
   * @throws Exception 
   */
  public int calcTPCPotPropulsorsObtencioVelocitat(String pIdCoet, int pVelocitatObjectiu) throws Exception
  { int pTPC = 0;
    boolean bOk=false;
    Coet coet = getCoet(pIdCoet);
    int dV0 = coet.getVelocitat();
    if(pVelocitatObjectiu<dV0) { return pTPC; } // La velocitat ja est� assolida  
    //El calcul es seq�encial provant fins trobar un % que satisfaga la condici�. 
    //Per evitar calculs repetitius es podria tenir una taula per al coet on especifiques q
    //per a un TPC x la suma del propulsors operant a aquella potencia es Y
    for(int dTPCPotenciaPropulsors=1;dTPCPotenciaPropulsors<=100;dTPCPotenciaPropulsors++)
    { int dPotPropulsorsAlTPC = coet.getPotenciaPropulsorsTPC(dTPCPotenciaPropulsors);
      int vTPC = (int) (dV0+100*(java.lang.Math.sqrt((double)dPotPropulsorsAlTPC)));            
      if(vTPC>pVelocitatObjectiu) // <-- % minim per assolir la velocitat dessitjada
      { pTPC = dTPCPotenciaPropulsors;
        bOk=true;
        break;
      }
    }
    if(bOk==false)
    { throw new Exception("El coet "+pIdCoet+" no te potencia per assolir la velocitat "+pVelocitatObjectiu);
    }
    return pTPC;
  }
  
  
  
  
  
  
  

}
