package view;

import java.util.Arrays;

import controller.Nivell1ControllerClass;
import model.Coet;
import model.Propulsor;

public class AppCoetNivell1Fase3 
{

  public static void main(String[] main)
  { 
    AppCoetNivell1Fase3 oAppCoet = new AppCoetNivell1Fase3();
    
    oAppCoet.run();  
    
  }

    
  private void run() 
  {
    
    final Nivell1ControllerClass oControllerClassNivell1 = new Nivell1ControllerClass(); // apuntador al contrller desde la vista

    // El traspas de dades hauria de ser amb alguna estructura de dades no lligada al ... per simplicitat
    oControllerClassNivell1.afegeixCoet(new Coet("32WESSDS", 0,
                                                 Arrays.asList( new Propulsor[] { new Propulsor(10,0) , new Propulsor(30,0) , new Propulsor(80,0) } )));  
    oControllerClassNivell1.afegeixCoet(new Coet("LDSFJA32", 0,
                                                 Arrays.asList( new Propulsor[] { new Propulsor(30,0) , new Propulsor(40,0) ,
                                                                                  new Propulsor(50,0),  new Propulsor(50,0),
                                                                                  new Propulsor(30,0),  new Propulsor(10,0) } )));
    
    //Establi el % de potencia en que ha d'operar el coet ( cada un desl propulsors)
    try { oControllerClassNivell1.setPercentatgePotenciaCoet("32WESSDS",65); }
    catch (Exception e) { e.printStackTrace(); }
    //Establi el % de potencia en que ha d'operar el coet ( cada un desl propulsors)    
    try { oControllerClassNivell1.setPercentatgePotenciaCoet("LDSFJA32",75); } 
    catch (Exception e) { e.printStackTrace(); }
    
    //--- Per a testejar en sentit invers 
    try { oControllerClassNivell1.setPercentatgePotenciaActual("32WESSDS",95); }
    catch (Exception e) { e.printStackTrace(); }   
    try { oControllerClassNivell1.setPercentatgePotenciaActual("LDSFJA32",85); } 
    catch (Exception e) { e.printStackTrace(); }
    
    Thread t1 = new Thread() { public void run() { oControllerClassNivell1.sincronitzaPotencia("32WESSDS"); } } ;
    Thread t2 = new Thread() { public void run() { oControllerClassNivell1.sincronitzaPotencia("LDSFJA32"); } } ;
    t1.start();
    t2.start();
    try { t1.join(); } catch (InterruptedException e) { e.printStackTrace(); }
    try { t2.join(); } catch (InterruptedException e) { e.printStackTrace(); }
    System.out.println("Finalitzat!!");
    
    
  }
  
  
  
}
