package view;

import java.util.Arrays;

import controller.Nivell1ControllerClass;
import model.Coet;
import model.Propulsor;

public class AppCoetNivell2 
{

  public static void main(String[] main)
  { 
    AppCoetNivell2 oAppCoet = new AppCoetNivell2();
    oAppCoet.run();      
  }

  
  
  private void run() 
  { int dTPCPotPropulsors = 0;
    int velocitatInicial = 0;
    
    final Nivell1ControllerClass oControllerClassNivell1 = new Nivell1ControllerClass(); // apuntador al contrller desde la vista

    // El traspas de dades hauria de ser amb alguna estructura de dades no lligada al ... per simplicitat
    velocitatInicial = 50;
    oControllerClassNivell1.afegeixCoet(new Coet("32WESSDS",velocitatInicial ,
                                                 Arrays.asList( new Propulsor[] { new Propulsor(10,0) , new Propulsor(30,0) , new Propulsor(80,0) } )));
    
    velocitatInicial = 80;
    oControllerClassNivell1.afegeixCoet(new Coet("LDSFJA32", velocitatInicial,
                                                 Arrays.asList( new Propulsor[] { new Propulsor(30,0) , new Propulsor(40,0) ,
                                                                                  new Propulsor(50,0),  new Propulsor(50,0),
                                                                                  new Propulsor(30,0),  new Propulsor(10,0) } )));
    
    dTPCPotPropulsors = 0;
    try
    { //El coet  "32WESSDS" va a una velicitat de 50   
      dTPCPotPropulsors = oControllerClassNivell1.calcTPCPotPropulsorsObtencioVelocitat("32WESSDS",1700); 
      System.out.println("El coet 32WESSDS ha d'operar al "+dTPCPotPropulsors+" % de potencia per assolir la velocitat.");
    }
    catch(Exception ex)
    { System.out.println("Excepcio:"+ex.getMessage());
    }
    

    dTPCPotPropulsors = 0;
    try
    { //El coet  "32WESSDS" va a una velicitat de 50   
      dTPCPotPropulsors = oControllerClassNivell1.calcTPCPotPropulsorsObtencioVelocitat("LDSFJA32",830); 
      System.out.println("El coet LDSFJA32 ha d'operar al "+dTPCPotPropulsors+" % de potencia per assolir la velocitat.");
    }
    catch(Exception ex)
    { System.out.println("Excepcio:"+ex.getMessage());
    }
    
    
    System.out.println("Finalitzat!!");
    
        
    
  }
  
  
  
}
