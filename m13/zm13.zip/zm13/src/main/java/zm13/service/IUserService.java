package zm13.service;

import zm13.dto.UserResponseDto;

public interface IUserService {

    UserResponseDto getUser(String uuid);
}
