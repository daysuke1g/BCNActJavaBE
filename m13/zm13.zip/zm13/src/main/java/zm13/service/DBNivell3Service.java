package zm13.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import zm13.beans.Empleat;
import zm13.repository.DBNivell3;
import zm13.repository.IDBEmpleat;

@Service
public class DBNivell3Service implements IDBEmpleat
{
  @Autowired
  DBNivell3 bd;  

  //insert method
  public boolean create(Empleat pEmpleat) throws Exception 
  { System.out.println("DBNivell3Service.create() called");
    bd.save(pEmpleat);  
    return true;
  }
  
  //delete method
  public boolean delete(int pId)
  { System.out.println("DBNivell3Service.delete() called");
    bd.deleteById(pId); 
    return true;
  }
 
  //Update method
  public boolean update(Empleat pEmpleat) throws Exception 
  { System.out.println("DBNivell3Service.update() called");
    bd.save(pEmpleat); 
    return false;
  }

  //Get ... empleat by Id
  public Empleat getEmpleatById(int pId)
  { System.out.println("DBNivell3Service.getEmpleatById() called");
    Optional<Empleat> l = bd.findById(pId);
    return l.get();
  }
  
  // Get ... tots els empleats
  public List<Empleat> getEmpleats()
  { System.out.println("DBNivell3Service.getEmpleats() called");
    return (List<Empleat>) bd.findAll();
  }
  
  //Si tipusfeina es null o en blanc retornar tots el empleats 
  // sino buscar i retornar per tipus de feina
  public List<Empleat> getEmpleatsPerTipusFeina(String tipusFeina)  
  { try
    { if(tipusFeina == null ) return getEmpleats();
      tipusFeina = tipusFeina.trim();
      if(tipusFeina.equals("")) { return getEmpleats(); }     
      return bd.findByFeina(Empleat.tipusFeina(tipusFeina));  
    }
    catch (Exception e)  
    { e.printStackTrace(); 
    }
    return null; 
  } 
  
}

