package zm13.dto;

public abstract class ResponseDto {
}
