package zm13.controller;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import zm13.beans.Empleat;
import zm13.repository.IDBEmpleat;
import zm13.service.DBNivell3Service;

//@RestController  --- hara que los metodos returnen @ResponseBody y no sean interpretados como paginas
@Controller
@RequestMapping("/n3")
public class ControllerNivell3  
{
  @Autowired
  DBNivell3Service bd;
  
  
  // Metode de test 
  @GetMapping("/test")    //    http://127.0.0.1:8080/n3/test  
  public String testMethod() 
  { return "infoPage";
  }

  /**
   * Metode inicial. LLista els empleats sobre la plana i prepara l'operacio d'insert
   * @param model
   * @return
   */
  @GetMapping("/empleats")    //    http://127.0.0.1:8080/n3/empleats
  public String nivell3Page(Model model) 
  { System.out.println("ControllerNivell2 /n3/empleats -> nivell3Page");
    List<Empleat> alEmpleats = bd.getEmpleats();
    model.addAttribute("empleats",alEmpleats);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    model.addAttribute("boton","Inserta Empleat");
    model.addAttribute("action","/n3/empleats");       
    return "nivell3Page";
  }
   
  /**
   * Procesar insert de dades amb una petico POST
   * @param model
   * @param name
   * @param setFeinaByString
   * @return
   */
  @PostMapping("/empleats")
  public String insertar(Model model,String name,String setFeinaByString)  
  { System.out.println("Entrando en POST /empleats con :" + name + " " +setFeinaByString);
    try { boolean b = bd.create(new Empleat(name, setFeinaByString)); }
    catch(Exception ex) { ; }
    List<Empleat> alEmpleats = bd.getEmpleats();
    model.addAttribute("empleats",alEmpleats);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    model.addAttribute("boton","Inserta Empleat");
    model.addAttribute("action","/n3/empleats");    
    return "nivell3Page";    
  }  
  
  
  /**
   * Esborra l'empleat id de la BBDD. Fer-ho amb GET teoricament trenca amb les best practices  
   */
  @GetMapping("/empleats/delete/{id}")
  public String borrar(@PathVariable int id,Model model)
  { System.out.println("Entrando en GET /empleats/delete/"+id);    
    bd.delete(id);
    List<Empleat> alEmpleats = bd.getEmpleats();
    model.addAttribute("empleats",alEmpleats);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    model.addAttribute("boton","Inserta Empleat");
    model.addAttribute("action","/n3/empleats");    
    return "nivell3Page";    
  }
  
  /**
   * Mostra al formulari les dades de l'empleat a actualitzar  
   */
  @GetMapping("/empleats/update/{id}")
  public String updateLoad(@PathVariable int id,Model model)
  { System.out.println("Entrando en GET /empleats/update/"+id);    
    List<Empleat> alEmpleats = bd.getEmpleats();
    Empleat e = bd.getEmpleatById(id);
    model.addAttribute("empleats",alEmpleats);
    model.addAttribute("empleat",e);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    try { model.addAttribute("cbsel",e.getTipusFeina()); } 
    catch(Exception ex) { ; } 
    model.addAttribute("boton","Actualitza Empleat");
    model.addAttribute("action","/n3/empleats/update");    
    return "nivell3Page";    
  }

  
  /**
   * Procesar update amb les dades que arriben amb el metode POST desde el formulari
   * @param model
   * @param id
   * @param name
   * @param setFeinaByString
   * @return
   */
  @PostMapping("/empleats/update")
  public String update(Model model,int id,String name,String setFeinaByString)  
  { System.out.println("Entrando en POST /empleats/update con :" + id + " "+ name + " " +setFeinaByString);
    try 
    { Empleat e = bd.getEmpleatById(id);
      e.setNom(name);
      e.setFeinaByString(setFeinaByString);
      bd.update(e); 
    }
    catch(Exception ex) { ; }
    List<Empleat> alEmpleats = bd.getEmpleats();
    model.addAttribute("empleats",alEmpleats);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    model.addAttribute("boton","Inserta Empleat");
    model.addAttribute("action","/n3/empleats");    
    return "nivell3Page";    
  } 

  
  /**
   * Procesar la busqueda pel tipus de feina amb l'string 'tipusfeina'que arriba desde el formulari de cerca
   * @param model
   * @param selFeinaByString
   * @return
   */
  
  @PostMapping("/buscaPerTipusFeina")
  public String buscarPerTipusFeina(Model model,String selFeinaByString)  //, @RequestBody String postPayload   
  { System.out.println("Entrando en POST /n3/buscaPerTipusFeina con :" + selFeinaByString);
    List<Empleat> lEmpleats = bd.getEmpleatsPerTipusFeina(selFeinaByString);    
    model.addAttribute("empleats",lEmpleats);
    model.addAttribute("lTipusFeina",Empleat.lTipusFeina);
    model.addAttribute("boton","Inserta Empleat");
    model.addAttribute("action","/n3/empleats");    
    return "nivell3Page";    
  }    
  
  
}
