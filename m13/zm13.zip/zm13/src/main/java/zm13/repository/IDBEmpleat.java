package zm13.repository;

import java.util.List;

import zm13.beans.Empleat;

public interface IDBEmpleat 
{ 
  public boolean create(Empleat pEmpleat) throws Exception ;
  public boolean update(Empleat pEmpleat) throws Exception ;   
  public boolean delete(int pId);
  public List<Empleat> getEmpleats() ;
  public Empleat getEmpleatById(int pId);  
  public List<Empleat> getEmpleatsPerTipusFeina(String tipusFeina); 
  
  
}
