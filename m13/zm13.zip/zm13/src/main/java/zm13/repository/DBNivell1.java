package zm13.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import zm13.beans.Empleat;

public class DBNivell1 implements IDBEmpleat
{ 
  private ArrayList<Empleat> mALEmpleats = new ArrayList<Empleat>(); // estructura de dades 
  
  public DBNivell1()  // Constructor .. inicialitzo una serie d'instancies per a probar
  { for(int dIdx=1;dIdx<=18;dIdx++)
    { String szNom  = String.format("Nivell1 Nom Empleat %d",dIdx);
      zm13.beans.Empleat.TIPUS_FEINA tipusFeina;  
      if(dIdx==1)      { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.MANAGER; } 
      else if(dIdx<=3) { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.CAP_DE_PROJECTE; }
      else if(dIdx<=6) { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.ANALISTA_PROGRAMADOR; }
      else if(dIdx<=11){ tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.PROGRAMADOR_SENIOR; }
      else             { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.PROGRAMADOR_JUNIOR; }
      try { create(new Empleat(szNom,tipusFeina)); }
      catch(Exception ex) { ; } 
    }
  }

  public List<Empleat> getEmpleats() { return mALEmpleats; }
  
  private void setEmpleats(ArrayList<Empleat> pALEmpleats) { mALEmpleats = pALEmpleats; }
  
  //Insert operation
  public boolean  create(Empleat pEmpleat) { return mALEmpleats.add(pEmpleat); }   
  
  //Delete operation
  public boolean delete(int pId) 
  { Iterator<Empleat> it = mALEmpleats.iterator();
    while(it.hasNext())
    { Empleat e = it.next();
      if(e.getId()==pId)
      { it.remove();
        return true;
      }
    }  
    return false;
  }
  
  //GetById Operation
  public Empleat getEmpleatById(int pId)
  { Iterator<Empleat> it = mALEmpleats.iterator();
    while(it.hasNext())
    { Empleat e = it.next();
      if(e.getId()==pId)
      { return e;
      }
    }    
    return null;
  }

  //Buscar empleats per tipus de feina
  public List<Empleat> getEmpleatsPerTipusFeina(String tipusFeina)
  { ArrayList<Empleat> alEmpTipusFeina = new ArrayList<Empleat>();
  
    if(tipusFeina==null) { return getEmpleats(); } 
    tipusFeina = tipusFeina.trim();
    if(tipusFeina.equals("")) { return getEmpleats(); }  
  
    try
    { Empleat.TIPUS_FEINA enumTF = Empleat.tipusFeina(tipusFeina);
      Iterator<Empleat> it = mALEmpleats.iterator();
      while(it.hasNext())
      { Empleat e = it.next();
        if(e.getFeina()==enumTF)
        { alEmpTipusFeina.add(e);
        }
      }  
    }
    catch(Exception ex) { ; }
    return alEmpTipusFeina;
  }
  
  //Update operation
  public boolean update(Empleat pEmpleat) throws Exception 
  { boolean poUpdated = false;
    Iterator<Empleat> it = mALEmpleats.iterator();
    while(it.hasNext())
    { Empleat e = it.next();
      if(e.getId()==pEmpleat.getId())
      { e.setNom(pEmpleat.getNom());
        e.setFeina(pEmpleat.getFeina());
        return true;
      }
    }       
    return false;
  }
  
}
