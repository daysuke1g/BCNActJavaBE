package zm13.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import zm13.beans.Empleat;
import zm13.beans.Empleat.TIPUS_FEINA;

public interface DBNivell3 extends JpaRepository<Empleat,Integer>
{
  
  //@org.springframework.scheduling.annotation.Async
  @Query("SELECT e FROM Empleat e where e.feina = :codFeina") 
  public List<Empleat> findByFeina(@Param("codFeina") Empleat.TIPUS_FEINA codFeina); 
  
  
}
