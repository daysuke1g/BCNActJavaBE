package zm13.repository;

import zm13.beans.Empleat;
import zm13.dto.ResponseDto;

public interface IRepository 
{ 
  public ResponseDto getUser(String uuid);
}
