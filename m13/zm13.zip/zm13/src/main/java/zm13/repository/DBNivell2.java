package zm13.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import zm13.beans.Empleat;
import zm13.beans.Empleat.TIPUS_FEINA;

public class DBNivell2 implements IDBEmpleat
{ 
  private Connection conexion;
 
  public DBNivell2()
  { try
    { Class.forName("com.mysql.cj.jdbc.Driver");
      String strCon="jdbc:mysql://localhost:3306/zztest00";
      this.conexion = DriverManager.getConnection(strCon,"root","mysql");
    }
    catch(Exception e)
    { e.printStackTrace();
    } 
    
    deleteAll();
    for(int dIdx=1;dIdx<=18;dIdx++)
    { String szNom  = String.format("MySQL JDBC Nom Empleat %d",dIdx);
      zm13.beans.Empleat.TIPUS_FEINA tipusFeina;  
      if(dIdx==1)      { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.MANAGER; } 
      else if(dIdx<=3) { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.CAP_DE_PROJECTE; }
      else if(dIdx<=6) { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.ANALISTA_PROGRAMADOR; }
      else if(dIdx<=11){ tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.PROGRAMADOR_SENIOR; }
      else             { tipusFeina = zm13.beans.Empleat.TIPUS_FEINA.PROGRAMADOR_JUNIOR; }
      try { create(new Empleat(szNom,tipusFeina)); }
      catch(Exception ex) { ; } 
    }
  }

  private void deleteAll() 
  { Statement stmt = null;
    try
    { stmt = conexion.createStatement();
      stmt.executeUpdate("delete from empleat;");
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(stmt!=null)
      { try { stmt.close(); }
        catch(Exception e) { ; }
      }
    }        
  }
   
  //Insert operation
  public boolean create(Empleat pEmpleat) throws Exception 
  { boolean pobRet = false;

    PreparedStatement ps = null;
    //String strQuery = "insert into empleat (id,nom,feina,salari) values(?,?,?,?);";    
    String strQuery = "insert into empleat (nom,feina,salari) values(?,?,?);";
    try
    { ps = conexion.prepareStatement(strQuery);
      //ps.setInt(1,pEmpleat.getId());
      ps.setString(1,pEmpleat.getNom());
      ps.setInt(2,pEmpleat.getFeina().ordinal());
      ps.setFloat(3,pEmpleat.getSalari());
      if(ps.executeUpdate()>0) 
      { pobRet = true;
      }
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(ps!=null)
      { try { ps.close(); }
        catch(Exception e) { ; }
      }
    }
    return pobRet;        
  }
  
  public List<Empleat> getEmpleats() 
  { ArrayList<Empleat> alEmpleats = new ArrayList<Empleat>(); 
    
    Statement stmt = null;
    ResultSet  rs = null;        
    try
    { stmt = conexion.createStatement();
      if(stmt.execute("select * from empleat order by id;"))
      { rs = stmt.getResultSet();
        while(rs.next())
        { try 
          { alEmpleats.add(new Empleat(rs.getInt("id"),
                                       rs.getString("nom"),
                                       Empleat.TIPUS_FEINA.values()[rs.getInt("feina")]
                                      )
                          );
          }
          catch(Exception e) { ; } 
        }
      }
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(rs!=null)
      { try { rs.close(); }
        catch(Exception e) { ; }
      }
      if(stmt!=null)
      { try { stmt.close(); }
        catch(Exception e) { ; }
      }
    }
    return alEmpleats; 
  }
  
  //Delete operation
  public boolean delete(int pId) 
  { boolean pobRet = false;
    PreparedStatement ps = null;
    try
    { ps = conexion.prepareStatement("delete from empleat where id = ?");
      ps.setInt(1,pId);
      if(ps.executeUpdate()>0) { pobRet = true; }       
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(ps!=null)
      { try { ps.close(); }
        catch(Exception e) { ; }
      }
    }
    return pobRet;
  }

  // Retorna un empleat per Id
  public Empleat getEmpleatById(int pId)
  { Empleat poEmpleat = null;
    PreparedStatement ps = null;
    ResultSet rs = null;   
    try
    { ps = conexion.prepareStatement("select * from empleat where id = ?");
      ps.setInt(1,pId);
      if(ps.execute())
      { rs = ps.getResultSet();
        if(rs.next())
        { try 
          { poEmpleat = new Empleat(rs.getInt("id"),
                                    rs.getString("nom"),
                                    Empleat.TIPUS_FEINA.values()[rs.getInt("feina")]);
          }
          catch(Exception e) 
          { e.printStackTrace();         
          }        
        }
      }
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(rs!=null)
      { try { rs.close(); }
        catch(Exception e) { ; }
      }
      if(ps!=null)
      { try { ps.close(); }
        catch(Exception e) { ; }
      }
    }    
    return poEmpleat;
  }

  //Buscar empleats per tipus de feina
  public List<Empleat> getEmpleatsPerTipusFeina(String tipusFeina)
  { ArrayList<Empleat> alEmpTipusFeina = new ArrayList<Empleat>();

    // Si no arriba res informat....tots 
    if(tipusFeina==null) { return getEmpleats(); } 
    tipusFeina = tipusFeina.trim();
    if(tipusFeina.equals("")) { return getEmpleats(); }  

    Statement stmt = null;
    ResultSet  rs = null;        
    try
    { stmt = conexion.createStatement();
      if(stmt.execute("select * from empleat where feina = "+Empleat.tipusFeina(tipusFeina).ordinal()+" order by id;"))
      { rs = stmt.getResultSet();
        while(rs.next())
        { try 
          { alEmpTipusFeina.add(new Empleat(rs.getInt("id"),
                                            rs.getString("nom"),
                                            Empleat.TIPUS_FEINA.values()[rs.getInt("feina")]
                                           )
                               );
          }
          catch(Exception e) { ; } 
        }
      }
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    catch(Exception ex)
    { System.out.println(ex.getMessage());
    }
    finally
    { if(rs!=null)
      { try { rs.close(); }
        catch(Exception e) { ; }
      }
      if(stmt!=null)
      { try { stmt.close(); }
        catch(Exception e) { ; }
      }
    }               
    return alEmpTipusFeina;
  }
 
  //Update operation
  public boolean update(Empleat pEmpleat) throws Exception 
  { boolean poUpdated = false;

    PreparedStatement ps = null;
    String strQuery = "update empleat set nom = ? , feina = ? , salari = ? where id = ?";      
    try
    { ps = conexion.prepareStatement(strQuery);    
      ps.setString(1,pEmpleat.getNom());
      ps.setInt(2,pEmpleat.getFeina().ordinal());
      ps.setFloat(3,pEmpleat.getSalari());
      ps.setInt(4,pEmpleat.getId());
      if(ps.executeUpdate()>0)
      { poUpdated = true;
      }
    }
    catch(SQLException e)
    { System.out.println(e.getMessage());
    }
    finally
    { if(ps!=null)
      { try { ps.close(); }
        catch(Exception e) { ; }
      }
    }
    return false;
  }
  
  
}
