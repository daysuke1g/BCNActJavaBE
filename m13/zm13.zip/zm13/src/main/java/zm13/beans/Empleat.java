package zm13.beans;

import java.util.HashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="empleat")
public class Empleat 
{ private static int mNumEmpleat = 1; 
  
  public static enum TIPUS_FEINA { PROGRAMADOR_JUNIOR,
                                   PROGRAMADOR_SENIOR,
                                   ANALISTA_PROGRAMADOR,
                                   CAP_DE_PROJECTE,
                                   MANAGER
                                 } ;
                                 
  public static final String[] lTipusFeina = { "PROGRAMADOR_JUNIOR", "PROGRAMADOR_SENIOR", "ANALISTA_PROGRAMADOR", "CAP_DE_PROJECTE", "MANAGER" } ;

  public static final HashMap<TIPUS_FEINA,Float> mSousFeina = new HashMap<TIPUS_FEINA,Float>();                            
  static
  { mSousFeina.put(TIPUS_FEINA.PROGRAMADOR_JUNIOR,  20000f);
    mSousFeina.put(TIPUS_FEINA.PROGRAMADOR_SENIOR,  30000f);
    mSousFeina.put(TIPUS_FEINA.ANALISTA_PROGRAMADOR,40000f);
    mSousFeina.put(TIPUS_FEINA.CAP_DE_PROJECTE,     50000f);
    mSousFeina.put(TIPUS_FEINA.MANAGER,             60000f);
  }
 
  
  @Id
  @Column(name="id")
  @GeneratedValue(strategy=GenerationType.IDENTITY)  
  private int id;
  
  private String nom; 
  
  private TIPUS_FEINA feina;
  
  private float salari;
  
  
  public Empleat() { }
  
  public Empleat(String nom, TIPUS_FEINA feina) throws Exception 
  { super();
    this.id = Empleat.mNumEmpleat++;
    this.nom = nom;
    setFeina(feina);
  }

  public Empleat(int pId,String nom, TIPUS_FEINA feina) throws Exception 
  { super();
    this.id = pId;
    this.nom = nom;
    setFeina(feina);
  }
  
  public Empleat(String nom, String tipusFeina) throws Exception 
  { super();
    this.id = Empleat.mNumEmpleat++;
    this.nom = nom;
    setFeina(tipusFeina(tipusFeina));
  }
  
  public int getId() { return id; }
  private void setId(int id) { this.id = id; }

  public String getNom() { return nom; }
  public void setNom(String nom) { this.nom = nom; }

  public TIPUS_FEINA getFeina() { return feina; }
  public String getTipusFeina() throws Exception
  { return tipusFeina(feina);
  }  
  
  public void setFeina(TIPUS_FEINA feina) throws Exception 
  { String szFeina =  tipusFeina(feina);
    this.feina = feina;
    setSalari(mSousFeina.get(feina));
  }
  public void setFeinaByString(String szFeina) throws Exception 
  { this.feina = Empleat.tipusFeina(szFeina) ;
    setSalari(mSousFeina.get(feina));
  }
    
  public float getSalari() { return salari; }
  private void setSalari(float salari) {  this.salari = salari; }
  
  public static String tipusFeina(TIPUS_FEINA pTipusFeina) throws Exception
  { switch (pTipusFeina)
    { case PROGRAMADOR_JUNIOR:    { return "PROGRAMADOR_JUNIOR"; }
      case PROGRAMADOR_SENIOR:    { return "PROGRAMADOR_SENIOR"; }
      case ANALISTA_PROGRAMADOR : { return "ANALISTA_PROGRAMADOR"; }
      case CAP_DE_PROJECTE:       { return "CAP_DE_PROJECTE"; }
      case MANAGER:               { return "MANAGER"; }      
    }
    throw new Exception("Tipus de feina incorrecta"); 
  }
  
  public static TIPUS_FEINA tipusFeina(String pTipusFeina) throws Exception
  { switch (pTipusFeina)
    { case "PROGRAMADOR_JUNIOR":   { return TIPUS_FEINA.PROGRAMADOR_JUNIOR; }
      case "PROGRAMADOR_SENIOR":   { return TIPUS_FEINA.PROGRAMADOR_SENIOR; }
      case "ANALISTA_PROGRAMADOR": { return TIPUS_FEINA.ANALISTA_PROGRAMADOR; }
      case "CAP_DE_PROJECTE":      { return TIPUS_FEINA.CAP_DE_PROJECTE; }
      case "MANAGER":              { return TIPUS_FEINA.MANAGER; }
    }
    throw new Exception("Tipus de feina incorrecta"); 
  }

  @Override
  public String toString() 
  { String szTipusFeina = ""; 
    try { szTipusFeina = tipusFeina(feina) ; } 
    catch(Exception ex) { }
    return "Empleat [id=" + id + ", nom=" + nom + ", feina=" + szTipusFeina + ", salari=" + salari + "]";
  }  
  
 
  
  
  
}
