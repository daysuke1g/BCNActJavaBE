package util;

public class Formatter 
{

  public static final java.text.DecimalFormat mDf4d = new java.text.DecimalFormat("0000");
  public static final java.text.DecimalFormat mDf2d = new java.text.DecimalFormat("00");
  
  
  public static final String calendarToString(java.util.Calendar c)
  { String calendarStr = mDf2d.format(c.get(java.util.Calendar.DAY_OF_MONTH)) + "/" + 
                         mDf2d.format(c.get(java.util.Calendar.MONTH)+1)+ "/" + 
                         mDf4d.format(c.get(java.util.Calendar.YEAR))+ " " +
                         mDf2d.format(c.get(java.util.Calendar.HOUR_OF_DAY))+ ":" +
                         mDf2d.format(c.get(java.util.Calendar.MINUTE))+ ":" +
                         mDf2d.format(c.get(java.util.Calendar.SECOND));    
    return calendarStr;
  }
}
