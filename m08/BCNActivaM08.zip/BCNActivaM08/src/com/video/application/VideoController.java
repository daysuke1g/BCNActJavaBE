package com.video.application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.video.domain.Tag;
import com.video.domain.Usuari;
import com.video.domain.Video;

public class VideoController 
{
  //List<Usuari>   usuaris;
  HashMap<String,Usuari> mHMUsuaris = new HashMap<String,Usuari>();
  
  public VideoController() 
  { //usuaris = new ArrayList<>();
    
    generarUsuarisperDefecte();
  }

  
  public void crearVideo(String pUserId,String strUrl, String strTitol,int durada, List<Tag> llistaTags) throws Exception
  { 
    Usuari usr = getUsuariById(pUserId); 
    if(usr==null)                { throw new Exception("Usuari inexistent."); }    
    if(strUrl==null)             { throw new Exception("Cal informar la url"); }         
    strUrl = strUrl.trim();
    if(strUrl.equals(""))        { throw new Exception("Cal informar la url"); }    
    if(strTitol==null)           { throw new Exception("Cal informar del titol"); }         
    strTitol = strTitol.trim();
    if(strTitol.equals(""))      { throw new Exception("Cal informar del titol"); }
    if(llistaTags==null)         { throw new Exception("Cal informar la llista de tag."); }
    if(llistaTags.size()==0)     { throw new Exception("Cal informar com a m�nim d'un tag"); }
    for(Tag t : llistaTags)
    { String szTag = t.getTag();
      if(szTag==null)  { throw new Exception("Els Tags no poden tenir valor null."); }
      szTag = szTag.trim();
      if(szTag.equals("")) { throw new Exception("Els Tags no poden tenir valor null."); }
    }
    //--------------
    
    Video v = new Video(strUrl,strTitol,durada,llistaTags); // Crear objecte Video a afegir a la llista de videos de l'usuari. 
    addVideoToUser(usr,v); 
     
  }  
  
  private void addVideoToUser(Usuari pUsr, Video v) 
  {
    String szKey = pUsr.getId();
    Usuari usr = mHMUsuaris.get(szKey);
    if(usr==null) { usr = pUsr; }
    
    List<Video> lUsrVideos = usr.getVideos();
    if(lUsrVideos==null)  
    { lUsrVideos = new ArrayList<Video>();
      lUsrVideos.add(v);
      usr.setVideos(lUsrVideos);
      mHMUsuaris.put(szKey,usr);
    }
    else
    { lUsrVideos.add(v);
    }
  }

  /**
   * El controlador accedeix al model prepara les dades per a ser visualitzades segons un format
   * i retorna les dades la View per a que les mostri. En aquest cas, una llista de String amb la
   * informacio dels videos de l'usuari.  
   * @param pUserId
   * @return
   * @throws Exception
   */
  
  public List<String> mostrarVideosUsuari(String pUserId) throws Exception 
  { List<String> pListDataToView = null;
  
    Usuari usr = mHMUsuaris.get(pUserId);
    if(usr!=null)
    { List<Video> lUsrVideos = usr.getVideos();
      if(lUsrVideos!=null) 
      { pListDataToView = new ArrayList<String>();
        for(Video v : lUsrVideos)
        { pListDataToView.add(v.toString());
        }
      }
    }    
    return pListDataToView;
  }  
  
  //public List<Usuari> getUsuaris() 
  //{ //List<Usuari> x = new ArrayList(mHMUsuaris.values()) ;
  //  return usuaris;
  //}
  public Collection<Usuari> getUsuaris() 
  { //List<Usuari> x = new ArrayList(mHMUsuaris.values()) ;
    return mHMUsuaris.values();
  }
  
  public boolean existeixUsuari(String pUserId) 
  { for(Usuari u :  mHMUsuaris.values())
    { if(u.getId().equals(pUserId)) { return true; }    
    }
    return false;
  }
  
  public Usuari getUsuariById(String pUserId) 
  { for(Usuari u :  mHMUsuaris.values())
    { if(u.getId().equals(pUserId)) { return u; }    
    }
    return null;
  }  
  
/**
 * Operacion del controlador que gestiona peticions de la vista sobre videos d'usuari: 
 *      Reproduccio, pausa i parar
 * @param pUserId
 * @param dIdVideo
 * @param pOperacio
 * @throws Exception
 */
  public void operacioVideoUsuari(String pUserId, int dIdVideo,String pOperacio) throws Exception 
  { Usuari usr = getUsuariById(pUserId); 
    if(usr==null) { throw new Exception("Usuari inexistent."); }
    List<Video> lUsrVideos = usr.getVideos();
    if(lUsrVideos!=null) 
    { Video vToPlay=null;
      for(Video v : lUsrVideos)
      { if(v.getId()==dIdVideo)
        { vToPlay = v; 
          break;
        }
      }
      if(vToPlay==null) { throw new Exception("Video inexistent per a l'usuari."); }
      switch(pOperacio)
      { case "R": // reproduir
        { vToPlay.reproduir(); // <<---- Crida el model
          break;
        }
        case "P": // pausar
        { vToPlay.pausar(); // <<---- Crida el model
          break;
        }
        case "A": // parar/aturar
        { vToPlay.parar(); // <<---- Crida el model
          break;
        }
      }      
    }
  }



  
  
  /**
   * Funcio d'utilitat per generar usuaris i videos i inicialitzar l'estructura de dades.
   */
  private void generarUsuarisperDefecte() 
  {
    Date date = new Date();
    Calendar c = Calendar.getInstance(); 

    c.set(1920,0,1,0,0); //Mes=0 -> gener  
    date.setTime(c.getTimeInMillis());
    Usuari usr1 = new Usuari("1","Nom Usuari 1","Cognoms Usuari 1","PWDUSR1",date);
    mHMUsuaris.put(usr1.getId(), usr1);
    
    c.set(1920,1,1,0,0); //Mes=1 -> febrer  
    date.setTime(c.getTimeInMillis());
    Usuari usr2 = new Usuari("2","Nom Usuari 2","Cognoms Usuari 2","PWDUSR2",date);    
    mHMUsuaris.put(usr2.getId(), usr2);
    
    c.set(1920,2,1,0,0); //Mes=2 -> mar�  
    date.setTime(c.getTimeInMillis());
    Usuari usr3 = new Usuari("3","Nom Usuari 3","Cognoms Usuari 3","PWDUSR3",date);
    mHMUsuaris.put(usr3.getId(), usr3);
    
    c.set(1920,3,1,0,0); //Mes=3 -> abril  
    date.setTime(c.getTimeInMillis());
    Usuari usr4 = new Usuari("4","Nom Usuari 4","Cognoms Usuari 4","PWDUSR4",date);
    mHMUsuaris.put(usr4.getId(), usr4);
    
    
    ArrayList<Tag> alTags = new ArrayList<Tag>();
    alTags.add(new Tag("Tag1Video1")); alTags.add(new Tag("Tag2Video1"));
    Video v = new Video("UrlVideo1Usr1","TitolVideo1Usr1",330,alTags);  
    addVideoToUser(usr1,v);    
    
    alTags.clear();
    alTags.add(new Tag("Tag1Video2")); alTags.add(new Tag("Tag2Video2"));alTags.add(new Tag("Tag3Video2"));
    v = new Video("UrlVideo2Usr1","TitolVideo2Usr1",90,alTags);  
    addVideoToUser(usr1,v);     
    
    alTags.clear();
    alTags.add(new Tag("Tag1Video3")); alTags.add(new Tag("Tag2Video3"));
    v = new Video("UrlVideo3Usr1","TitolVideo3Usr1",45,alTags);  
    addVideoToUser(usr1,v);    
    
    
  }





  
}
