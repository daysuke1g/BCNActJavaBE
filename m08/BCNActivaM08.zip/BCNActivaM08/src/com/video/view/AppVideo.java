package com.video.view;

import java.util.Collection;
import java.util.List;

import com.video.application.VideoController;
import com.video.domain.Usuari;
import com.video.domain.Video;

public class AppVideo
{
  protected VideoController  mVideoController; // instancia de controlador
  protected VideoViews       mVideoViews;      // instancia de gestor de vistes  
      
  public static void main(String[] args)
  { 
    AppVideo oAppVideo = new AppVideo(); 
    oAppVideo.run();
    oAppVideo.finish();   
  }
  
  public AppVideo() 
  { 
    mVideoController = new VideoController();  // obtenir controlador
    mVideoViews      = new VideoViews(mVideoController); // afegir apuntador al controlador a la vista 
  }

  private void run() 
  {
    //Agafo un usuari per defecte per les operacions que es demanen a la practica
    //List<Usuari> llistaUsuaris = mVideoController.getUsuaris();
    String userId = null;
    Collection<Usuari> colUsuaris = mVideoController.getUsuaris();
    for(Usuari u:colUsuaris)
    { if(u.getId().equalsIgnoreCase("1"))
      userId = u.getId();
      break;
    }
    
    while(true)
    { System.out.println("------------------------------------------------------------------");
      String userSelection = mVideoViews.showMainMenu();
      if(userSelection.equalsIgnoreCase("S")) { break; } // sortir
      switch(userSelection)
      { case "MenuVideos": { mVideoViews.menuVideosUsuari(mVideoController,userId); break; }
      }      
    }    
    
  }
  
  private void finish() 
  { mVideoViews.finish();    
  }

  
  
}
