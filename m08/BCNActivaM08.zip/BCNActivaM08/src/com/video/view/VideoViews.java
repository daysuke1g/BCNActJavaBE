package com.video.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.video.application.VideoController;
import com.video.domain.Tag;

public class VideoViews 
{ protected Scanner          mInputScanner;
  protected VideoController  mVideoController;

  @SuppressWarnings("unused")
  private VideoViews() 
  {   
  }
  
  public VideoViews(VideoController  pVideoController) 
  { mInputScanner    = new Scanner(System.in);  
    mVideoController = pVideoController;
  }

  public String showMainMenu() 
  { String pUserSelection="";
    
    boolean bSalir = false;
    while(!bSalir)
    { System.out.println("----------------------------------------------------");
      System.out.println("Menu principal seleccioni operacio:");
      System.out.println("1-Sortir");
      System.out.println("2-Menu Videos");
      String strInput = mInputScanner.nextLine();
      if(strInput==null) continue;
      switch(strInput)
      { case "1": { pUserSelection = "S"; bSalir=true; break; }
        case "2": { pUserSelection = "MenuVideos"; bSalir=true; break; }
      }      
    }
    return pUserSelection;
  }


  public void finish()
  { if(mInputScanner!=null) { mInputScanner.close(); }     
  }

  /**
   * 
   * @param pVideoController
   * @param pUserId
   * 
   * Menu d'operacions sobre videos 
   * -Crear video per a usuari
   * -Mostrar la llista de videos d'un usuari 
   * 
   */
  public void menuVideosUsuari(VideoController pVideoController,String pUserId)
  { String pUserSelection="";
    while(!pUserSelection.equalsIgnoreCase("S"))
    { System.out.println("----------------------------------------------------");
      System.out.println("Menu operacions d'usuari seleccioni operacio:");
      System.out.println("1-Sortir");
      System.out.println("2-Crear video usuari actual");
      System.out.println("3-Veure videos usuari actual");
      System.out.println("4-Reproduir/Pausar/Parar video usuari actual");      
      String strInput = mInputScanner.nextLine();
      if(strInput==null) continue;
      switch(strInput)
      { case "1": { pUserSelection = "S"; break; }
        case "2": { crearVideo(pUserId); break; }
        case "3": { mostrarVideos(pUserId); break; }
        case "4": { operacioAmbVideoVideo(pUserId); break; }
        
      }      
    }
  }

  /**
   * View per a crear videos ... es demanen dades i es crida al Controller per realitzar l'operacio
   * @param pUserId
   */
  private void crearVideo(String pUserId)
  {
    System.out.println("----------------------------------------------------");
    System.out.println("Crear video:");
    System.out.println("Introdueixi url:"); String strUrl = mInputScanner.nextLine();
    System.out.println("Introdueixi titol:"); String strTitol = mInputScanner.nextLine();
    System.out.println("Introdueixi durada en segons:"); String strDurada = mInputScanner.nextLine();
    
    List<Tag> llistaTags = new ArrayList<Tag>();
    while(true)
    { System.out.println("Introdueixi tag inicial (q-finalitzar):"); String strTag = mInputScanner.nextLine();
      if(strTag==null) { continue; } 
      strTag = strTag.trim();
      if(strTag.equalsIgnoreCase("")) { continue; } 
      if(strTag.equalsIgnoreCase("q")) 
      { if(llistaTags.size()>0) { break; }
          else { System.out.println("Cal introdu�r un al menys un tag."); }
      }
      else
      { llistaTags.add(new Tag(strTag));
      }
      
    }
    try
    { mVideoController.crearVideo(pUserId,strUrl,strTitol,Integer.parseInt(strDurada),llistaTags); // <----------------- crida al controller
    }
    catch(Exception ex)
    { System.out.println("Excepcio al crar el video :"+ex.getMessage());
      
    }
    
  }
  
  /**
   * Mostra els videos de l'usuari actual. El format de representacio de retorn es una llista d'String 
   * @param pUserId
   */
  private void mostrarVideos(String pUserId) 
  {
    try
    { List<String> listDataToView = mVideoController.mostrarVideosUsuari(pUserId);  // <----------------- crida al controller
      if(listDataToView==null)
      { System.out.println("No s'han trobat videos per aquest usuari.");  
      }
      else
      { for(String s:listDataToView)
        { System.out.println(s);
        }        
      }
    }
    catch(Exception ex)
    { System.out.println("Excepcio al crar el video :"+ex.getMessage());      
    }    
    
  }
  
  /**
   * Reprodueix un video de l'usuari actual
   * @param pUserId
   */
  private void operacioAmbVideoVideo(String pUserId)
  {
    try
    { List<String> listDataToView = mVideoController.mostrarVideosUsuari(pUserId);  // <----------------- crida al controller
      if(listDataToView==null)
      { System.out.println("No s'han trobat videos per aquest usuari.");
        return;
      }
      
      System.out.println("Seleccioni operaci�");
      System.out.println("1-Sortir");
      System.out.println("2-Reproduir video");
      System.out.println("3-Pausar video");
      System.out.println("4-Aturar video");      
      String strOperation = mInputScanner.nextLine();
      if(strOperation==null) { return ; } 
      
      switch(strOperation)
      { case "2": { ; break; }
        case "3": { ; break; }
        case "4": { ; break; }
        default: { return; }
      }            
            
      boolean bSortir = false;
      while(!bSortir)
      { System.out.println("Seleccioni el id del video (q-sortir):");
        for(String s:listDataToView)
        { System.out.println(s);
        }  
        String strInput = mInputScanner.nextLine();
        if(strInput!=null)
        { if(strInput.equalsIgnoreCase("q")) { bSortir=true; } 
          else
          { int dIdVideo=0;
            try 
            { dIdVideo = Integer.parseInt(strInput);
              if((dIdVideo>=1)&&(dIdVideo<=listDataToView.size()))
              { switch(strOperation)
                { case "2": { mVideoController.operacioVideoUsuari(pUserId,dIdVideo,"R"); bSortir=true; break; } // <---- Crida al controller
                  case "3": { mVideoController.operacioVideoUsuari(pUserId,dIdVideo,"P"); bSortir=true; break; } // <---- Crida al controller
                  case "4": { mVideoController.operacioVideoUsuari(pUserId,dIdVideo,"A"); bSortir=true; break; } // <---- Crida al controller; 
                  default: { return; }
                }                    
              
              }
            }
            catch(NumberFormatException nfe)  { ; }
          }
        }
      }
    }
    catch(Exception ex)
    { System.out.println("Excepcio l'operar sobre el video :"+ex.getMessage());      
    }    
    

  }


}
