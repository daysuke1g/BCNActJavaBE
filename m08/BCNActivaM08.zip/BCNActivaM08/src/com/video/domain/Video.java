package com.video.domain;

import java.util.Calendar;
import java.util.List;

public class Video 
{
  public static int mIntervalDeTempsEntreEstats = 20;  // <<------------ Temps en ser visible desde la creaci�

  private static int mIdNum = 1; 
  
  protected int    id;
  protected String url;
  protected String titol;
  protected List<Tag> tags;
  
  //Membres nivell 2
  protected Calendar       dataPujada;
  protected Estat_Pujada   estat;
  enum Estat_Pujada { UPLOADING, VERIFYING, PUBLIC }
  
  //Membres nivell 3  
  enum Estat_Reproduccio { PARAT, PAUSAT, REPRODUCCIO }
  protected Estat_Reproduccio status;
  protected Calendar       iniciReproduccio;
  protected int            segonsReproduits;
  protected int  durada; 

  public Video(String url, String titol, int durada, List<Tag> tags) 
  { super();
  
    id         = mIdNum++;
    this.url   = url;
    this.titol = titol;
    this.tags  = tags;
    
    dataPujada= Calendar.getInstance();
    estat = Estat_Pujada.UPLOADING;
    
    this.durada = durada; 
    
    initVarsReporduccio();
   
  }
  
  private void initVarsReporduccio() 
  { status = Estat_Reproduccio.PARAT;
    iniciReproduccio = null;
    segonsReproduits = 0;
  }

  public int getId() {
    return id;
  }
  
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }
  public String getTitol() {
    return titol;
  }
  public void setTitol(String titol) {
    this.titol = titol;
  }
  public List<Tag> getTags() {
    return tags;
  }
  public void setTags(List<Tag> tags) {
    this.tags = tags;
  }
 
  
  
  @Override
  public String toString() 
  { StringBuilder sb = new StringBuilder("");
    sb.append("Video [id="+ id + ",url=" + url + ",titol=" + titol + ",tags=");
    for(Tag t : tags)
    { sb.append(t.getTag()+" / ");
    }
    sb.append(",Data Pujada=" + util.Formatter.calendarToString(dataPujada) + ",estat="+ getEstat()+ ",durada=" + 
              durada + ",Status rep.=" + getStatusDesc() + "]");    
    return sb.toString();
  }

  /**
   * Retorna i actualitza l'estat en funci� de la diferencia de temps entre el calendar actual i el de la instanciacio.
   * @return
   */
  private String getEstat() 
  { String poEstat ="";

    if ( estat == Estat_Pujada.PUBLIC ) { return "PUBLIC"; } ;
  
    java.util.Calendar currentCalendar = java.util.Calendar.getInstance();
    long difTimeInMillis = currentCalendar.getTimeInMillis() - dataPujada.getTimeInMillis();
    
    java.util.concurrent.TimeUnit timeUnit = java.util.concurrent.TimeUnit.SECONDS; 
    long difTimeInSeconds = timeUnit.convert(difTimeInMillis, java.util.concurrent.TimeUnit.MILLISECONDS);
    
    if     (difTimeInSeconds>40) { estat = Estat_Pujada.PUBLIC;    return "PUBLIC"; }
    else if(difTimeInSeconds>20) { estat = Estat_Pujada.VERIFYING; return "VERIFYING"; }
    else                         { poEstat = "UPLOADING"; }

    return poEstat;
  } 
  
  public Estat_Reproduccio getStatus() 
  { checkTimeReproduccio();
    return status;
  }
  
  public void setStatus(Estat_Reproduccio status) {
    this.status = status;
  }
  
  /**
   * Retorna l'estat de reproducco en format String  
   * @return
   */
  private String getStatusDesc() 
  { checkTimeReproduccio();
    if      ( status == Estat_Reproduccio.PARAT ) { return "PARAT";  } 
    else if ( status == Estat_Reproduccio.PAUSAT) { return "PAUSAT a "+segonsReproduits+" seg."; } 
    else if ( status == Estat_Reproduccio.REPRODUCCIO ) { return "REPRODUCCIO a "+getSegonsReproduccio()+" seg."; }     
    return "";
  }

  /**
   * REPRODUIR
   * 1-Check si s'esta reproduint i ha passat el temps de duracio del video. LLavors aturar i reinicialitzar
   * 2-Si esta parat arrancar reproduccio
   *   si esta pausat continuar reproduint
   *   si ja esta en reproduccio, avisar amb excepcio
   * @throws Exception
   */
  public void reproduir() throws Exception
  {
    checkTimeReproduccio();
    
    if(status==Estat_Reproduccio.PARAT)
    { status=Estat_Reproduccio.REPRODUCCIO;
      iniciReproduccio = Calendar.getInstance();
      segonsReproduits=0;
    }
    else if(status==Estat_Reproduccio.PAUSAT)
    { status=Estat_Reproduccio.REPRODUCCIO;
      iniciReproduccio = Calendar.getInstance();
      //segonsReproduits=0;
    }   
    else if(status==Estat_Reproduccio.REPRODUCCIO)
    { // No fer res o llan�ar excepcio ... 
      throw new Exception("Video actualment en reproduccio");
    }
    
  }

  /**
   * PAUSAR REPRODUCCIO
   * 1-Check si s'esta reproduint i ha passat el temps de duracio del video. LLavors aturar i reinicialitzar
   * 2-Si esta parat, avisar amb excepcio
   *   si esta pausat, avisar amb excepcio
   *   si ja esta en reproduccio, pausar i acumular segons.
   * @throws Exception
   */
  public void pausar() throws Exception
  {
    checkTimeReproduccio();
    
    if(status==Estat_Reproduccio.PARAT)
    { // No fer res o llan�ar excepcio ... 
      throw new Exception("Video actualment parat.");
    }
    else if(status==Estat_Reproduccio.PAUSAT)
    { // No fer res o llan�ar excepcio ... 
      throw new Exception("Video actualment pausat.");
    }   
    else if(status==Estat_Reproduccio.REPRODUCCIO)
    { 
      status=Estat_Reproduccio.PAUSAT;
      Calendar currTime = Calendar.getInstance();
      long difTimeInMillis = currTime.getTimeInMillis() - iniciReproduccio.getTimeInMillis();
      java.util.concurrent.TimeUnit timeUnit = java.util.concurrent.TimeUnit.SECONDS; 
      long difTimeInSeconds = timeUnit.convert(difTimeInMillis, java.util.concurrent.TimeUnit.MILLISECONDS);
      if( (difTimeInSeconds+segonsReproduits) < durada ) 
      { segonsReproduits+=difTimeInSeconds;
        iniciReproduccio=null;
      }
      else
      { initVarsReporduccio();
      }      
    }    
  }
  
  /**
   * 1-Check si s'esta reproduint i ha passat el temps de duracio del video. LLavors aturar i reinicialitzar
   * 2-Si esta parat, avisar amb excepcio
   *   si esta pausat o en reproduccio, aturar, avisar amb excepcio.
   * @throws Exception
   */
  public void parar() throws Exception
  { 
    checkTimeReproduccio();
    
    if(status==Estat_Reproduccio.PARAT)
    { // No fer res o llan�ar excepcio ... 
      throw new Exception("Video actualment parat.");
    }
    else if ( (status==Estat_Reproduccio.PAUSAT) || ((status==Estat_Reproduccio.REPRODUCCIO)) )
    { initVarsReporduccio();       
    }
  }
  
  /*
   * Reinicialitzar variables si arriba al temps maxim de reproduccio
   */
  private void checkTimeReproduccio()
  { if(status==Estat_Reproduccio.REPRODUCCIO)
    { if( getSegonsReproduccio() >= durada ) 
      { initVarsReporduccio();
      }    
    }
  }  
  
  private int getSegonsReproduccio()
  { if(status==Estat_Reproduccio.REPRODUCCIO)
    { long difTimeInMillis = Calendar.getInstance().getTimeInMillis() - iniciReproduccio.getTimeInMillis();
      java.util.concurrent.TimeUnit timeUnit = java.util.concurrent.TimeUnit.SECONDS; 
      long difTimeInSeconds = timeUnit.convert(difTimeInMillis, java.util.concurrent.TimeUnit.MILLISECONDS);
      return (int)difTimeInSeconds+segonsReproduits; 
    }
    return 0;
  }  
  
  

  
}

