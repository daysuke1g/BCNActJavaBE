package com.video.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Usuari 
{
  protected String   id;
  protected String   nom;
  protected String   cognom;
  protected String   password;
  protected Date     dataRegistre;
  protected List<Video> mlVideos;
  
  public Usuari(String id,String nom, String cognom, String password, Date dataRegistre) 
  { this.id = id;
    this.nom = nom;
    this.cognom = cognom;
    this.password = password;
    this.dataRegistre = dataRegistre;
  }

  public String getId() {
    return id;
  }


  public void setId(String id) {
    this.id = id;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public String getCognom() {
    return cognom;
  }

  public void setCognom(String cognom) {
    this.cognom = cognom;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Date getDataRegistre() {
    return dataRegistre;
  }

  public void setDataRegistre(Date dataRegistre) {
    this.dataRegistre = dataRegistre;
  }
  
  public List<Video> getVideos() {
    return mlVideos;
  }

  public void setVideos(List<Video> videos) {
    this.mlVideos = videos;
  }
  
  protected boolean addVideo(Video v)
  { boolean bRet = false;
    if(mlVideos==null)  
    { mlVideos = new ArrayList<Video>();
      bRet = mlVideos.add(v);
    }
    else
    { bRet = mlVideos.add(v);
    }    
    return bRet;
  }
  
  protected String getStringVideos()
  { String poRet = "";
    if(mlVideos!=null)  
    { for(Video v:mlVideos)
      { poRet = v.toString() + " / ";      
      }
    }    
    return poRet;
  }
  
  
  @Override
  public String toString() {
    return "Usuari [id=" + id + ",nom=" + nom + ",cognom=" + cognom + ",password=" + password + ",dataRegistre="
        + dataRegistre + ",videos=" + getStringVideos() + "]";
  }

  @Override
  public int hashCode() 
  { final int prime = 31;
    int result = 1;
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) 
  { if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Usuari other = (Usuari) obj;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    return true;
  }
  
  
     
  
}
