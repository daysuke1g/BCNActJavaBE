module BCNActivaM06 {
}