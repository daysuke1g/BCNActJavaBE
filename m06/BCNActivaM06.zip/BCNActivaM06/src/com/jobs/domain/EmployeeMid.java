package com.jobs.domain;

import com.jobs.application.PaymentFactory;

public class EmployeeMid extends Employee 
{ 
  public EmployeeMid(String name, String address, String phone, double salaryPerMonth)  throws Exception
  { super(name, address, phone,salaryPerMonth,PaymentFactory.createPaymentRateEmployeeMid());		
  }
  
}


