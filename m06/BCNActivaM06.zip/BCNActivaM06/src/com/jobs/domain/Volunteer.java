package com.jobs.domain;

public class Volunteer extends AbsStaffMember {
	String description;

	public Volunteer(String name, String address, String phone, String description) throws Exception {
		super(name, address, phone);
		//TODO
		this.description = description;
		checkSalary(); 
	}
	
	@Override
	public void pay() {
		totalPaid=0;
	}

	@Override
	public void checkSalary() throws Exception 
	{ if(totalPaid!=0) 
      { throw new Exception("Volunteer salary:No pot cobrar");
      }
	}	
	
	public String toString()
	{ return "Emp [name="+name+", address="+address+", phone="+phone+", descripcio="+description+", totalP="+totalPaid+"]";	 
	}	
}
