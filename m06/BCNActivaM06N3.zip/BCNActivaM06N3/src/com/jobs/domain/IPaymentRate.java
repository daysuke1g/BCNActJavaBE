package com.jobs.domain;

public interface IPaymentRate 
{
  public double  pay(double salaryPerMonth);
  public boolean checkSalary(double salaryPerMonth) throws Exception;
  public double  getIRPF();
  
}
