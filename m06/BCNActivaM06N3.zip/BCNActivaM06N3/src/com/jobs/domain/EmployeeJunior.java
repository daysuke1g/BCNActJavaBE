package com.jobs.domain;

import com.jobs.application.PaymentFactory;

public class EmployeeJunior extends Employee 
{ 
  public EmployeeJunior(String name, String address, String phone, double salaryPerMonth)  throws Exception
  { super(name, address, phone,salaryPerMonth,PaymentFactory.createPaymentRateEmployeeJunior());	
  }

}


