package com.jobs.domain;

public class Volunteer extends AbsStaffMember {
	String description;
	
	protected double ajut = 0; 

	public Volunteer(String name, String address, String phone, String description,double ajut) throws Exception {
		super(name, address, phone);
		//TODO
		this.description = description;
		checkSalary();
		setAjut(ajut);
	}
	
	@Override
	public void pay() {
		totalPaid=0;
	}

	@Override
	public void checkSalary() throws Exception 
	{ if(totalPaid!=0) 
      { throw new Exception("Volunteer salary:No pot cobrar");
      }
	}	
	
	public void setAjut(double ajut)
	{ if(ajut>0)
	  { this.ajut = ajut;
	  }
	  
	}
	
	public String toString()
	{ return "Emp [name="+name+", address="+address+", phone="+phone+", descripcio="+description+", totalP="+totalPaid+". te ajut="+
	         ((ajut>0)?"true":"false")+", ajut="+ajut+"]";	 
	}	
}
