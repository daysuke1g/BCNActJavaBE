package com.jobs.domain;

import com.jobs.application.PaymentFactory;

public class EmployeeSenior extends Employee 
{ 
  public EmployeeSenior(String name, String address, String phone, double salaryPerMonth)  throws Exception
  { super(name, address, phone,salaryPerMonth,PaymentFactory.createPaymentRateEmployeeSenior());		
  }
  
}


