package com.jobs.application;

import com.jobs.domain.IPaymentRate;

public class PaymentFactory {

	public static IPaymentRate createPaymentRateBoss(){
		return new IPaymentRate() {	
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*1.5;
			}
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if(salaryPerMonth<=8000) // Boss: Ha de cobrar  mes de  8000
              { throw new Exception("Boss salary:Ha de ser superior a 8000");
              }
              return true;
            }
			
			@Override
			public double getIRPF() { return 32; } 
		};
	}

	public static IPaymentRate createPaymentRateManager(){
		return new IPaymentRate() {	
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*1.1;
			}
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if((salaryPerMonth<=3000)||(salaryPerMonth>=5000)) // -Manager: Ha de cobrar mes  de 3000  pero  menys de 5000
              { throw new Exception("Manager salary:Ha de ser superior a 3000 i inferior a 5000");
              }
              return true;
            }	
			
			@Override
			public double getIRPF() { return 26; }
		};
	}
	
	public static IPaymentRate createPaymentRateEmployeeJunior(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*0.85; 
			}
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if((salaryPerMonth<=900)||(salaryPerMonth>=1600)) // -Junior: Ha de cobrar  mes  de 900  pero  menys de  1600
              { throw new Exception("Junior salary:Ha de ser superior a 900 i inferior a 1600");
              }
              return true;
            }	
			@Override
			public double getIRPF() { return 2; }
		};
	}	
	
	public static IPaymentRate createPaymentRateEmployeeMid(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*0.90; 
			}			
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if((salaryPerMonth<=1800)||(salaryPerMonth>=2500)) // -Midi: Ha de cobrar  mes  de 1800  pero  menys de  2500
              { throw new Exception("Mid salary:Ha de ser superior a 1800 i inferior a 2500");
              }
              return true;
            }
			@Override
			public double getIRPF() { return 15; }
		};
	}
	
	public static IPaymentRate createPaymentRateEmployeeSenior(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*0.95; 
			}			
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if((salaryPerMonth<=2700)||(salaryPerMonth>=4000)) // -Senior: Ha de cobrar  mes  de 2700  pero  menys de  4000
              { throw new Exception("Senior salary:Ha de ser superior a 2700 i inferior a 4000");
              }
              return true;
            }	
			@Override
			public double getIRPF() { return 24; }
		};
	}		
	

	
	/*
	public static IPaymentRate createPaymentRateEmployee(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return salaryPerMonth*0.85; 
			}
			
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if((salaryPerMonth<=900)||(salaryPerMonth>=4000)) // 
              { throw new Exception("Employee salary:Ha de ser superior a 900 i inferior a 4000");
              }
              return true;
            }				
		};
	}
	  
	public static IPaymentRate createPaymentRateVolunteer(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return 0; 
			}			
			@Override
            public boolean checkSalary(double salaryPerMonth) throws Exception
            { if(salaryPerMonth!=0) 
              { throw new Exception("Volunteer salary:No pot cobrar");
              }
              return true;
            }						
		};
	}	
			
	*/
	
}
