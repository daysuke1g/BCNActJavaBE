package test;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.jobs.application.JobsController;

class Test00 
{ private static JobsController controller;
  
  public static final String mBossMsg   = "Boss salary:Ha de ser superior a 8000";
  public static final String mJuniorMsg = "Junior salary:Ha de ser superior a 900 i inferior a 1600";
  public static final String mMidMsg    = "Mid salary:Ha de ser superior a 1800 i inferior a 2500";
  public static final String mSeniorMsg = "Senior salary:Ha de ser superior a 2700 i inferior a 4000";
  
  public static void main(String[] args) throws Exception
  { //JobsController controller  =new JobsController();
  }
	

  @DisplayName ("This method runs one time before all test")
  @BeforeAll
  public static void runBeforeAllTests()
  { controller = new JobsController();
  }
  
  @AfterAll
  @DisplayName ("This method runs one time after all test")
  public static void runAfterAllTests()
  {   
    controller.payAllEmployeers();

    String allEmployees=controller.getAllEmployees();
    System.out.println("EMPLOYEES: " + allEmployees + " \n");
	  
  }
  
  
  @BeforeEach
  @DisplayName ("This method runs before any test")
  public void runBeforeAnyTest()
  {   
  }
  
  @AfterEach
  @DisplayName ("This method runs after ny test")
  public void runAfterAnyTest()
  {   
  }
  
  @Test
  void testBoss() 
  { Exception exception = assertThrows(Exception.class,
              () -> { controller.createBossEmployee("Pepe Boss", "Direcci�n molona", "666666666", 100.0); } ) ;
    assertEquals(mBossMsg,exception.getMessage());
    
    exception = assertThrows(Exception.class,
            () -> { controller.createBossEmployee("Pepe Boss", "Direcci�n molona", "666666666", 8000.0); } ) ;
    assertEquals(mBossMsg,exception.getMessage());    
    
    try { controller.createBossEmployee("Pepe Boss", "Direcci�n molona", "666666666", 8001.0); }
    catch(Exception ex) 
    { fail("Excepcio no esperada:"+ex.getMessage());     
    }
  }
  
  @Test
  void testJunior() 
  { Exception exception = assertThrows(Exception.class,
              () -> { controller.createEmployeeJunior("Junior1 ", "Direcci�n molona 2", "665266666", 900);  } ) ;
    assertEquals(mJuniorMsg,exception.getMessage());
    
    exception = assertThrows(Exception.class,
            () -> { controller.createEmployeeJunior("Junior2 ", "Direcci�n molona 2", "665266666", 1600); } ) ;
    assertEquals(mJuniorMsg,exception.getMessage());    
    
    try { controller.createEmployeeJunior("Junior3 ", "Direcci�n molona 2", "665266666", 1500);  }
    catch(Exception ex) 
    { fail("Excepcio no esperada:"+ex.getMessage());     
    }	  	  
  }
  
  @Test
  void testMid() 
  { Exception exception = assertThrows(Exception.class,
              () -> { controller.createEmployeeMid("Mid1 ", "Direcci�n molona 2", "665266666", 1800); } ) ;
    assertEquals(mMidMsg,exception.getMessage());
    
    exception = assertThrows(Exception.class,
            () -> { controller.createEmployeeMid("Mid2 ", "Direcci�n molona 2", "665266666", 2500); } ) ;
    assertEquals(mMidMsg,exception.getMessage());    
    
    try { controller.createEmployeeMid("Mid3 ", "Direcci�n molona 2", "665266666", 2400);  }
    catch(Exception ex) 
    { fail("Excepcio no esperada:"+ex.getMessage());     
    }
  }
  
  
  @Test
  void testSenior() 
  { Exception exception = assertThrows(Exception.class,
          () -> { controller.createEmployeeSenior("Senior1 ", "Direcci�n molona 2", "665266666", 2700); } ) ;
    assertEquals(mSeniorMsg,exception.getMessage());

    exception = assertThrows(Exception.class,
          () -> { controller.createEmployeeSenior("Senior2 ", "Direcci�n molona 2", "665266666", 4000); } ) ;
    assertEquals(mSeniorMsg,exception.getMessage());    

    try { controller.createEmployeeSenior("Senior3 ", "Direcci�n molona 2", "665266666", 3900);  }
    catch(Exception ex) 
    { fail("Excepcio no esperada:"+ex.getMessage());     
    }	  
  }
  
  @Test
  void testVolunteer() 
  { try { controller.createVolunteer("Juan Volunteer", "Direcci�n molona 4", "614266666",200); } 
    catch(Exception ex) 
    { fail("Excepcio no esperada:"+ex.getMessage());     
    }
  }

  
  
  
  
  
  
  
  
}
