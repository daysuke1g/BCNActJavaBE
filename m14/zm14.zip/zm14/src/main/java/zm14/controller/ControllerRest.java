package zm14.controller; 

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import zm14.dao.BotiguesDAO;
import zm14.dao.CuadresDAO;
import zm14.model.Botiga;
import zm14.model.Cuadre;
import zm14.model.CuadreDTOWrapper;

@RestController            // Indica que esta clase va a ser un servicio RES                                     
@RequestMapping("/shops")  // Indica la URL que se va a exponer los servicios de esta clase   
public class ControllerRest 
{
  @Autowired //Inyeccion de dependencias 
  private BotiguesDAO mBotiguesDAO;

  @Autowired //Inyeccion de dependencias  
  private CuadresDAO mCuadresDAO;
  
  //TEST curl localhost:8080/shops/hello1
  @GetMapping("hello1")   
  public String hello() //@RequestMapping(value="", method=RequestMethod.GET) //En que url esta el servicio
  { return "hola amiguitos1!!";
  }

  
  //Retorna la llista de Botigues.    TEST curl -v localhost:8080/shops
  @GetMapping
  public ResponseEntity<List<Botiga>> getShops() // Si lo encuentra retorna 200 sino 204
  { List<Botiga> lShops = mBotiguesDAO.findAll();
    //if(lShops!=null) { lShops.stream().forEach(s->System.out.println(s.toString()));  }
    if(lShops!=null) { return ResponseEntity.ok(lShops); } 
       else { return ResponseEntity.noContent().build(); }         
  }

  
  //Creacio d'una botiga
  //TEST curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Botiga A\", \"capacitat\": 10 } " localhost:8080/shops
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Botiga B\", \"capacitat\": 15 } " localhost:8080/shops
  @PostMapping     
  public ResponseEntity<Botiga> create(@RequestBody Botiga botiga)
  { System.out.println(botiga.toString());
    Botiga newBotiga = mBotiguesDAO.save(botiga);
    return ResponseEntity.ok(newBotiga);           
  }

  
  //Afegir un cuadre a una botiga
  //TEST
  //curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Botiga A\", \"capacitat\": 10 } " localhost:8080/shops
  //curl -v localhost:8080/shops
  //curl --header "Content-Type: application/json" --request POST --data "{ \"botiga_id\": 4, \"nom\":\"Nom cuadreX\", \"autor\" : \"AutorX\", \"preu\": 1000.50, \"dataEntrada\": \"2021-07-24\" } " localhost:8080/shops/4/picture
  //curl --header "Content-Type: application/json" --request POST --data "{ \"botiga_id\": 4, \"nom\":\"Nom cuadreY\", \"autor\" : \"AutorY\", \"preu\": 1200.50, \"dataEntrada\": \"2021-07-23\" } " localhost:8080/shops/4/picture
  //curl --header "Content-Type: application/json" --request POST --data "{ \"botiga_id\": 4, \"nom\":\"Nom cuadreZ\", \"autor\" : \"AutorZ\", \"preu\": 1500.50, \"dataEntrada\": \"2021-07-22\" } " localhost:8080/shops/4/picture
  @PostMapping   
  @RequestMapping(value="/{shopId}/picture") 
  public ResponseEntity<CuadreDTOWrapper> addPictureToShop(@PathVariable("shopId") Long pShopId,@RequestBody Cuadre cuadre)
  { System.out.println(cuadre.toString());
  
    CuadreDTOWrapper poReturnVal = new CuadreDTOWrapper();          
    poReturnVal.ok = false;
    
    Optional<Botiga> optionalBotiga = mBotiguesDAO.findById(pShopId);    
    Botiga botiga = (optionalBotiga.isPresent())?optionalBotiga.get():null;
    if(botiga!=null)
    { Integer dNumCuadres = mCuadresDAO.countByBotiga_id(pShopId);
      if(dNumCuadres>=botiga.getCapacitat())
      { String szMsg = "La botiga "+pShopId+" ja esta al maxim de capacitat ("+botiga.getCapacitat()+")";
        System.out.println(szMsg);
        poReturnVal.msg0 = szMsg;
        return ResponseEntity.ok(poReturnVal);
      }
      else
      { cuadre.setBotiga(botiga);
        Cuadre newCuadre = mCuadresDAO.save(cuadre);
        poReturnVal.ok = true;
        poReturnVal.c  = newCuadre; 
        return ResponseEntity.ok(poReturnVal);
      }
    }
    return ResponseEntity.noContent().build();
  }
 
  
  //Llistar els quadres de la botiga (GET /shops/{ID}/pictures) 
  //TEST curl -v localhost:8080/shops/{ID}/pictures   curl -v --request GET localhost:8080/shops/3/pictures   
  @GetMapping
  @RequestMapping(value="/{botigaId}/pictures") 
  public ResponseEntity<List<Cuadre>> getPicturesByShShops(@PathVariable("botigaId") Long pBotigaId) // Si lo encuentra retorna 200 sino 204
  { List<Cuadre> lCuadres = mCuadresDAO.findByBotiga_id(pBotigaId);     
    if(lCuadres!=null) { return ResponseEntity.ok(lCuadres); } 
       else { return ResponseEntity.noContent().build(); }         
  }

  
  //Esborrar els cuadres d'una botiga
  //TEST curl -v --request DELETE localhost:8080/shops/3/pictures  
  @Transactional
  @RequestMapping(value="/{shopId}/pictures", method = RequestMethod.DELETE) // @RequestMapping(value = "/addUser", method = RequestMethod.POST)
  public ResponseEntity<String> deletePicturesOfShop(@PathVariable("shopId") Long pShopId)
  { int dNumRows = mCuadresDAO.deleteByBotiga_id(pShopId);
    System.out.println("Botiga " + pShopId.toString() + " esborrats "+dNumRows+" cuadres.");
    
    String szResponse = "{ \"botiga_id\": " + pShopId + ", \"registres_esborrats\" : "+dNumRows+"}";
    return ResponseEntity.ok(szResponse);
  }
 
 
}
