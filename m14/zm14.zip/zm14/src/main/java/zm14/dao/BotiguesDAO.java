package zm14.dao;

import zm14.model.Botiga;

import org.springframework.data.jpa.repository.JpaRepository;


public interface BotiguesDAO extends JpaRepository<Botiga,Long>
{

  

  
}
