package zm14.dao;

import zm14.model.Cuadre;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CuadresDAO extends JpaRepository<Cuadre,Long> 
{
  Integer countByBotiga_id(Long botiga_id);
  
  List<Cuadre> findByBotiga_id(Long botiga_id);
  
  int deleteByBotiga_id(Long botiga_id);
 
}


