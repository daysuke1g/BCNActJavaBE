package zm14.model;

public class CuadreDTOWrapper 
{ public boolean ok;
  public Cuadre  c;
  public String  msg0;   
}
