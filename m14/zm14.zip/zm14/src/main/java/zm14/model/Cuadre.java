package zm14.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="cuadres")
public class Cuadre
{
  @Id
  @Column(name="id")
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private long id;

  @Column(name="nom",nullable=false,length=100)
  private String nom;  
  
  @Column(name="autor",nullable=false,length=100)
  private String autor;  
  
  @Column(name="preu",nullable=false)
  private float preu;  
  
  @Column(name="data_ent",nullable=false)
  private Date dataEntrada;  
  
  @ManyToOne(fetch = FetchType.LAZY)  // FetchType.   EAGER    LAZY
  @JoinColumn(name="botiga_id", nullable=false)
  @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
  private Botiga botiga;

    
  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public String getNom() { return nom; }
  public void setNom(String nom) { this.nom = nom; }
  
  public String getAutor() { return autor; }
  public void setAutor(String autor) { this.autor = autor; }

  public float getPreu() { return preu; }
  public void setPreu(float preu) { this.preu = preu; }

  public Date getDataEntrada() { return dataEntrada; }
  public void setDataEntrada(Date dataEntrada) { this.dataEntrada = dataEntrada; }

  public Botiga getBotiga() { return botiga; }
  public void setBotiga(Botiga botiga) { this.botiga = botiga; }
  
  //@Override
  public String toString() {
    return "Cuadre [id=" + id + ", nom="+nom+", autor=" + autor + ", preu=" + preu + ", dataEntrada=" + dataEntrada + "]";
  }
  
  
}
