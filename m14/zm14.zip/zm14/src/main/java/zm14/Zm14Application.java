package zm14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class Zm14Application {

  public static void main(String[] args) {
    SpringApplication.run(Zm14Application.class, args);
  }

  // see https://spring.io/guides/gs/rest-service-cors/
  //     https://spring.io/blog/2015/06/08/cors-support-in-spring-framework
  @Bean
  public WebMvcConfigurer corsConfigurer() 
  { return new WebMvcConfigurer() {
       @Override
       public void addCorsMappings(CorsRegistry registry) 
       { //--registry.addMapping("/shops").allowedOrigins("http://localhost");
         registry.addMapping("/shops/**")
                 .allowedOrigins("http://localhost")
                 .allowedMethods("OPTIONS","GET","POST","PUT","DELETE");
       }
    };
  }
  
}
