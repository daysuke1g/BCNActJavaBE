delete from cuadres where 1 = 1;
delete from botigues where 1 = 1;

insert into botigues values (null,'Botiga 1',100);
insert into botigues values (null,'Botiga 2',200);
insert into botigues values (null,'Botiga 3',200);

insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,1,'Nom cuadre1','Cuadre1',1000,'2021-01-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,1,'Nom cuadre2','Cuadre2',1000,'2021-02-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,1,'Nom cuadre3','Cuadre3',1000,'2021-03-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,1,'Nom cuadre4','Cuadre4',1000,'2021-04-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,1,'Nom cuadre5','Cuadre5',1000,'2021-05-15');

insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre6','Cuadre6',1000,'2021-01-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre7','Cuadre7',1000,'2021-02-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre8','Cuadre8',1000,'2021-03-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre9','Cuadre9',1000,'2021-04-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre10','Cuadre10',1000,'2021-05-15');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre11','Cuadre11',1000,'2021-06-23');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre12','Cuadre12',1000,'2021-07-10');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,2,'Nom cuadre13','Cuadre13',1000,'2020-03-14');

insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre14','Cuadre14',1000,'2021-01-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre15','Cuadre15',1000,'2021-02-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre16','Cuadre16',1000,'2021-03-31');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre17','Cuadre17',1000,'2021-04-01');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre18','Cuadre18',1000,'2021-05-15');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre19','Cuadre19',1000,'2021-06-23');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre20','Cuadre20',1000,'2021-07-10');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre21','Cuadre21',1000,'2020-03-14');
insert into cuadres (id,botiga_id,nom,autor,preu,data_ent) values (null,3,'Nom cuadre22','Cuadre22',1000,'2020-03-14');

