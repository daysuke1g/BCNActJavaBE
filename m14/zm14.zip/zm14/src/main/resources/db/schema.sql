DROP TABLE IF EXISTS botigues;
CREATE TABLE botigues
( id        INT NOT NULL AUTO_INCREMENT ,
  nom       VARCHAR(100) NOT NULL,
  capacitat int NOT NULL,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS cuadres;
CREATE TABLE cuadres
( id        INT NOT NULL AUTO_INCREMENT ,
  botiga_id INT NOT NULL REFERENCES botigues(id),
  nom       VARCHAR(100) NOT NULL,
  autor     VARCHAR(100) NOT NULL,
  preu      DECIMAL(12,2) NOT NULL,
  data_ent  DATE NOT NULL,
  PRIMARY KEY (id)
);  