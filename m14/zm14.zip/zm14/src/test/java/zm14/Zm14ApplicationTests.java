package zm14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zm14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
