package springBootInitialDemoN3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInitialDemoN3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInitialDemoN3Application.class, args);
	}

}
