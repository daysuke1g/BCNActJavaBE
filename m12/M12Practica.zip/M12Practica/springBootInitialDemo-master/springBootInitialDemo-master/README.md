
### Spring Boot Initial Demo

Aplicación inicial que de muestra:
 - Flujo de inicialización
 - Separación de capas
 - Anotaciones Spring y carga de objetos