package springBootInitialDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springBootInitialDemo.dto.UserResponseDto;
import springBootInitialDemo.service.IUserService;

@RestController
@RequestMapping("/")
public class M12Nivell1Fase2 {

    @GetMapping("/")
    public String helloWorld() {
        return "HELLO WORLD";
    }

    @GetMapping("/Hello/{nom}")
    public String helloNom(@PathVariable(name="nom") String pNom)
    { return "Hello, "+ pNom;
    }
    
}
