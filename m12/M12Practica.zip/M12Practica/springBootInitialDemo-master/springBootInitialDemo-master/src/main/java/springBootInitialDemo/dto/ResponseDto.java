package springBootInitialDemo.dto;

public abstract class ResponseDto {
}
