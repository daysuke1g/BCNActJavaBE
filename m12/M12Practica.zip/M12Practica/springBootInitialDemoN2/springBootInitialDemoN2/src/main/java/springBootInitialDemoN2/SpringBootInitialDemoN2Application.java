package springBootInitialDemoN2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInitialDemoN2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInitialDemoN2Application.class, args);
	}

}
