package zm16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringM16TaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
