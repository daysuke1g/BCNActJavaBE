delete from tiradesn1 where 1 = 1;
delete from jugadorsn1 where 1 = 1;

insert into jugadorsn1 (id,nom,data_registre) values (null,'Anonim',SYSDATE());
insert into jugadorsn1 (id,nom,data_registre) values (null,'Jugador 1',SYSDATE());
insert into jugadorsn1 (id,nom,data_registre) values (null,'Jugador 2',SYSDATE());
insert into jugadorsn1 (id,nom,data_registre) values (null,'Jugador 3',SYSDATE());

insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,3,1,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,5,2,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,2,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,6,2,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,2,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,2,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,5,4,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,3,2,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,6,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,1,5,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,4,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,2,1,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,1,5,5,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,2,5,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,3,6,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,1,6,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,4,1,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,1,3,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,6,4,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,2,2,2,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,3,3,2,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,3,6,1,SYSDATE());
insert into tiradesn1 (id,jugador_id,dau1,dau2,data_tirada) values (null,3,3,1,SYSDATE());

delete from jocs       where 1 = 1;
delete from tiradesn2  where 1 = 1;
delete from jugadorsn2 where 1 = 1;

insert into jocs (id,nom) values (null,'7');
insert into jugadorsn2 (id,nom,anonim,data_registre) values (UUID(),'Jugador 0','S',SYSDATE());
insert into jugadorsn2 (id,nom,anonim,data_registre) values (UUID(),'Jugador 1','N',SYSDATE());
insert into jugadorsn2 (id,nom,anonim,data_registre) values (UUID(),'Jugador 2','N',SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,3,4,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,5,2,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,2,3,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,6,2,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,2,3,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,2,3,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,5,4,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,5,2,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,6,3,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,1,5,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select min(id) from jugadorsn2),1,4,3,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select max(id) from jugadorsn2),1,2,5,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select max(id) from jugadorsn2),1,3,6,SYSDATE());
insert into tiradesn2 (id,jugador_id,joc_id,dau1,dau2,data_tirada) values (UUID(),(select max(id) from jugadorsn2),1,1,6,SYSDATE());

