-- Nivell 1

DROP TABLE IF EXISTS jugadorsn1;
CREATE TABLE jugadorsn1
( id            INT NOT NULL AUTO_INCREMENT,
  nom           VARCHAR(100) NOT NULL,
  data_registre TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);
CREATE INDEX i1_jugadorsn1_nom on jugadorsn1(nom);

DROP TABLE IF EXISTS tiradesn1;
CREATE TABLE tiradesn1
( id          INT NOT NULL AUTO_INCREMENT,
  jugador_id  INT NOT NULL REFERENCES jugadorsn1(id),
  dau1        TINYINT UNSIGNED NOT NULL,
  dau2        TINYINT UNSIGNED NOT NULL,
  data_tirada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);  
CREATE INDEX i1_tiradesn1_jugador on tiradesn1(jugador_id);

-- Nivell 2

DROP TABLE IF EXISTS jocs;
CREATE TABLE jocs
( id          INT NOT NULL AUTO_INCREMENT,
  nom         VARCHAR(100) NOT NULL,
  PRIMARY KEY (id)
);
CREATE UNIQUE INDEX i1_jocs_nom on jocs(nom);

DROP TABLE IF EXISTS jugadorsn2;
CREATE TABLE jugadorsn2
( id            VARBINARY(36) NOT NULL,
  nom           VARCHAR(100) NOT NULL,
  anonim        CHAR(1) NOT NULL CHECK (anonim='S' or anonim='N'),
  data_registre TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);
CREATE INDEX i1_jugadorsn2_nom on jugadorsn2(nom);

DROP TABLE IF EXISTS tiradesn2;
CREATE TABLE tiradesn2
( id          VARBINARY(36) NOT NULL,
  jugador_id  VARBINARY(36) NOT NULL REFERENCES jugadorsn2(id),
  joc_id      INT NOT NULL REFERENCES jocs(id), 
  dau1        TINYINT UNSIGNED NOT NULL,
  dau2        TINYINT UNSIGNED NOT NULL,
  data_tirada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);  
CREATE INDEX i1_tiradesn2_jugador on tiradesn2(jugador_id);


