package zm16.model;

import java.sql.Timestamp;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
@Table(name="jugadorsn2")
public class PlayerN2 
{
  @Id
  @Column(name="id", columnDefinition = "VARBINARY(36)", updatable = false, nullable = false)  
  @GenericGenerator(name = "UUID",strategy = "org.hibernate.id.UUIDGenerator")
  @GeneratedValue(generator = "UUID")
  @Type(type="org.hibernate.type.UUIDCharType")
  private UUID id;

  @Column(name="nom",nullable=false,length=100)
  private String nom;  

  @Column(name="anonim",nullable=false,length=1)
  private String anonim;  
  
  @Column(name="data_registre", insertable = false, updatable = false)   
  private java.sql.Timestamp dataRegistre;
    
  @OneToMany(mappedBy="player") //  --> private PlayerN1 player;
  private Set<TiradaN1> tirades;   
  
  public PlayerN2() { }
  
  public PlayerN2(UUID id, String nom, String anonim, Timestamp dataRegistre) 
  { super();
    this.id = id;
    this.nom = nom;
    this.anonim = anonim;
    this.dataRegistre = dataRegistre;
  }

  public UUID getId() { return id; }
  public void setId(UUID id) { this.id = id; }

  public String getNom() { return nom; }
  public void setNom(String nom) { this.nom = nom; }

  public String getAnonim() { return anonim; }
  public void setAnonim(String anonim) { this.anonim = anonim; }

  public java.sql.Timestamp getDataRegistre() { return dataRegistre; }
  public void setDataRegistre(java.sql.Timestamp dataRegistre) { this.dataRegistre = dataRegistre; }  
  
  @Override
  public String toString() {
    return "PlayerN2 [id=" + id + ", nom=" + nom + ", dataRegistre=" + dataRegistre + "]"; // ", tirades=" + tirades +
  }   
}

