package zm16.model;

public class PlayerN1F2DTO
{
  public PlayerN1F2DTO(long id, String nom, java.util.Date dataRegistre, float percentatgeExit)
  { super();
    this.id = id;
    this.nom = nom;
    this.dataRegistre = dataRegistre;
    this.percentatgeExit = percentatgeExit;
  }
  private long      id;
  private String    nom;  
  private java.util.Date dataRegistre;
  private float     percentatgeExit;

  public PlayerN1F2DTO() 
  {
    
  }
  
  public long getId() {return id; }
  public void setId(long id) {this.id = id; }
  public String getNom() { return nom; }
  public void setNom(String nom) {this.nom = nom; }
  //public java.util.Date getDataRegistre() { return dataRegistre; }
  //public void setDataRegistre(java.util.Date dataRegistre) {this.dataRegistre = dataRegistre; }
  public java.util.Date getDataRegistre() { return dataRegistre; }
  public void setDataRegistre(java.util.Date dataRegistre) {this.dataRegistre = dataRegistre; }
  public float getPercentatgeExit() { return percentatgeExit; }
  public void setPercentatgeExit(float percentatgeExit) { this.percentatgeExit = percentatgeExit; }

  @Override
  public String toString() {
    return "PlayerN1F2DTO [id=" + id + ", nom=" + nom + ", dataRegistre=" + dataRegistre + ", percentatgeExit="
        + percentatgeExit + "]";
  }
  
  
  
}
