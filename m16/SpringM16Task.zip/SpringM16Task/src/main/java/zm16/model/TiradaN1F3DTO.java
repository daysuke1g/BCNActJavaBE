package zm16.model;

import java.sql.Timestamp;

public class TiradaN1F3DTO 
{
  private long  id;
  private short dau1;  
  private short dau2;  
  private java.sql.Timestamp dataTirada;
  private long  jugador;

  public TiradaN1F3DTO() { }  
  
  public TiradaN1F3DTO(long id, short dau1, short dau2, Timestamp dataTirada, long jugador)
  { super();
    this.id = id;
    this.dau1 = dau1;
    this.dau2 = dau2;
    this.dataTirada = dataTirada;
    this.jugador = jugador;
  }

  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public short getDau1() { return dau1; }
  public void setDau1(short dau1) { this.dau1 = dau1; }

  public short getDau2() { return dau2; }
  public void setDau2(short dau2) { this.dau2 = dau2; }

  public java.sql.Timestamp getDataTirada() { return dataTirada; }
  public void setDataTirada(java.sql.Timestamp dataTirada) { this.dataTirada = dataTirada; }

  public long getJugador() { return jugador; }
  public void setJugador(long jugador) { this.jugador = jugador; }
  
}

