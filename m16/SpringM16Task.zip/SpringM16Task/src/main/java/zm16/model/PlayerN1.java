package zm16.model;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="jugadorsn1")
public class PlayerN1 
{
  @Id
  @Column(name="id")
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private long id;

  @Column(name="nom",nullable=false,length=100)
  private String nom;  

  @Column(name="data_registre", insertable = false, updatable = false)   
  private java.sql.Timestamp dataRegistre;
    
  @OneToMany(mappedBy="player") //  --> private PlayerN1 player;
  private Set<TiradaN1> tirades;   
  
  public PlayerN1() { }
  
  public PlayerN1(long id, String nom, Timestamp dataRegistre) {
    super();
    this.id = id;
    this.nom = nom;
    this.dataRegistre = dataRegistre;
  }

  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public String getNom() { return nom; }
  public void setNom(String nom) { this.nom = nom; }

  public java.sql.Timestamp getDataRegistre() { return dataRegistre; }
  public void setDataRegistre(java.sql.Timestamp dataRegistre) { this.dataRegistre = dataRegistre; }  

  @Override
  public String toString() {
    return "PlayerN1 [id=" + id + ", nom=" + nom + ", dataRegistre=" + dataRegistre + "]"; // ", tirades=" + tirades +
  }   
}

