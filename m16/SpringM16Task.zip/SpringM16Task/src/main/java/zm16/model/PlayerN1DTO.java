package zm16.model;

import java.sql.Timestamp;

public class PlayerN1DTO
{
  public PlayerN1DTO(long id, String nom, Timestamp dataRegistre, float percentatgeExit)
  { super();
    this.id = id;
    this.nom = nom;
    this.dataRegistre = dataRegistre;
    this.percentatgeExit = percentatgeExit;
  }
  private long      id;
  private String    nom;  
  private java.sql.Timestamp dataRegistre;
  private float     percentatgeExit;

  public PlayerN1DTO() 
  {
    
  }
  
  public long getId() {return id; }
  public void setId(long id) {this.id = id; }
  public String getNom() { return nom; }
  public void setNom(String nom) {this.nom = nom; }
  public java.sql.Timestamp getDataRegistre() { return dataRegistre; }
  public void setDataRegistre(java.sql.Timestamp dataRegistre) {this.dataRegistre = dataRegistre; }
  public float getPercentatgeExit() { return percentatgeExit; }
  public void setPercentatgeExit(float percentatgeExit) { this.percentatgeExit = percentatgeExit; }
  
}
