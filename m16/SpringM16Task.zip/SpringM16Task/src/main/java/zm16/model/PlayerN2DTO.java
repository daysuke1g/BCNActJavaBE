package zm16.model;

import java.sql.Timestamp;
import java.util.UUID;

public class PlayerN2DTO
{ private UUID      id;
  private String    nom;  
  private String    anonim;  
  private java.sql.Timestamp dataRegistre;
  private float     percentatgeExit;

  public PlayerN2DTO(UUID id, String nom, String anonim,Timestamp dataRegistre, float percentatgeExit)
  { super();
    this.id = id;
    this.nom = nom;
    this.dataRegistre = dataRegistre;
    this.anonim = anonim; 
    this.percentatgeExit = percentatgeExit;
  }
 
  public PlayerN2DTO() 
  {
    
  }

  public UUID getId() {return id; }
  public void setId(UUID id) {this.id = id; }
  public String getNom() { return nom; }
  public void setNom(String nom) {this.nom = nom; }
  public String getAnonim() { return anonim; }
  public void setAnonim(String anonim) { this.anonim = anonim; }  
  public java.sql.Timestamp getDataRegistre() { return dataRegistre; }
  public void setDataRegistre(java.sql.Timestamp dataRegistre) {this.dataRegistre = dataRegistre; }
  public float getPercentatgeExit() { return percentatgeExit; }
  public void setPercentatgeExit(float percentatgeExit) { this.percentatgeExit = percentatgeExit; }
  
}
