package zm16.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="tiradesn1")
public class TiradaN1 
{
  @Id
  @Column(name="id")
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private long id;

  @Column(name="dau1",nullable=false)
  private short dau1;  
  
  @Column(name="dau2",nullable=false)
  private short dau2;  
  
  @Column(name="data_tirada", insertable = false, updatable = false)  
  private java.sql.Timestamp dataTirada;

  @ManyToOne(fetch = FetchType.LAZY)  // FetchType.   EAGER    LAZY
  @JoinColumn(name="jugador_id", nullable=false)
  @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
  private PlayerN1 player;

  public TiradaN1() { }  
  
  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public short getDau1() { return dau1; }
  public void setDau1(short dau1) { this.dau1 = dau1; }

  public short getDau2() { return dau2; }
  public void setDau2(short dau2) { this.dau2 = dau2; }

  public java.sql.Timestamp getDataTirada() { return dataTirada; }
  public void setDataTirada(java.sql.Timestamp dataTirada) { this.dataTirada = dataTirada; }

  public PlayerN1 getPlayer() { return player; }
  public void setPlayer(PlayerN1 player) { this.player = player; }

  @Override
  public String toString() 
  { return "TiradaN1 [id=" + id + ", dau1=" + dau1 + ", dau2=" + dau2 + ", dataTirada=" + dataTirada + ", player=" + player + "]";
  }
  
}

