package zm16.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="jugadorsn1")
public class PlayerN1F2 
{
  @Id
  private long id;
  @Field(name="nom")
  private String nom;  
  @Field(name="data_registre")   
  private java.util.Date data_registre;

  public PlayerN1F2() 
  {
  }

  public PlayerN1F2(long id, String nom, java.util.Date data_registre)
  { super();
    this.id = id;
    this.nom = nom;
    this.data_registre = data_registre;
  }

  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public String getNom() { return nom; }
  public void setNom(String nom) { this.nom = nom; }

  public java.util.Date getData_registre() { return data_registre; }
  public void setData_registre(java.util.Date data_registre) { this.data_registre = data_registre; }

  @Override
  public String toString() 
  { return "PlayerN1F2 [id=" + id + ", nom=" + nom + ", data_registre=" + data_registre + "]";
  }
  
}


