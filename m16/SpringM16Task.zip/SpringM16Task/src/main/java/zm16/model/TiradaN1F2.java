package zm16.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="tiradesn1")
public class TiradaN1F2 
{
  @Id
  private long id;

  @Field(name="dau1")
  private short dau1;  
  
  @Field(name="dau2")
  private short dau2;  
  
  @Field(name="data_tirada")  
  private java.util.Date dataTirada;

  @Field(name="jugador_id")
  private long jugador;

  public TiradaN1F2() { }  
  
  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public short getDau1() { return dau1; }
  public void setDau1(short dau1) { this.dau1 = dau1; }

  public short getDau2() { return dau2; }
  public void setDau2(short dau2) { this.dau2 = dau2; }

  public java.util.Date getDataTirada() { return dataTirada; }
  public void setDataTirada(java.util.Date dataTirada) { this.dataTirada = dataTirada; }

  public long getPlayer() { return jugador; }
  public void setPlayer(long jugador) { this.jugador = jugador; }

  @Override
  public String toString() 
  { return "TiradaN1F2 [id=" + id + ", dau1=" + dau1 + ", dau2=" + dau2 + ", dataTirada=" + dataTirada + ", jugador=" + jugador + "]";
  }
  
}

