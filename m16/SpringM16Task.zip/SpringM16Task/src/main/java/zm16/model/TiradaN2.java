package zm16.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="tiradesn2")
public class TiradaN2 
{
  @Id
  @Column(name="id", columnDefinition = "VARBINARY(36)", updatable = false, nullable = false)
  @GenericGenerator(name = "UUID",strategy = "org.hibernate.id.UUIDGenerator")
  @GeneratedValue(generator = "UUID")
  @Type(type="org.hibernate.type.UUIDCharType")
  private UUID id;
  
  @Column(name="dau1",nullable=false)
  private short dau1;  
  
  @Column(name="dau2",nullable=false)
  private short dau2;  
  
  @Column(name="data_tirada", insertable = false, updatable = false)  
  private java.sql.Timestamp dataTirada;

  @ManyToOne(fetch = FetchType.LAZY)  // FetchType.   EAGER    LAZY
  @JoinColumn(name="jugador_id", nullable=false)
  @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
  private PlayerN2 player;

  @ManyToOne(fetch = FetchType.LAZY)  // FetchType.   EAGER    LAZY
  @JoinColumn(name="joc_id", nullable=false)
  @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
  private JocN2 joc;
  
  public TiradaN2() { }  
  
  public UUID getId() { return id; }
  public void setId(UUID id) { this.id = id; }

  public short getDau1() { return dau1; }
  public void setDau1(short dau1) { this.dau1 = dau1; }

  public short getDau2() { return dau2; }
  public void setDau2(short dau2) { this.dau2 = dau2; }

  public java.sql.Timestamp getDataTirada() { return dataTirada; }
  public void setDataTirada(java.sql.Timestamp dataTirada) { this.dataTirada = dataTirada; }

  public PlayerN2 getPlayer() { return player; }
  public void setPlayer(PlayerN2 player) { this.player = player; }

  public JocN2 getJoc() { return joc; }
  public void setJoc(JocN2 joc) { this.joc = joc; }
  
  @Override
  public String toString() 
  { return "TiradaN2 [id=" + id + ", dau1=" + dau1 + ", dau2=" + dau2 + ", dataTirada=" + dataTirada + ", player=" + player + "]";
  }
  
}

