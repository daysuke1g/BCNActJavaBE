package zm16.model;

import java.sql.Timestamp;
import java.util.UUID;

public class TiradaN2DTO 
{
  private UUID    id;
  private short   dau1;  
  private short   dau2;  
  private java.sql.Timestamp dataTirada;
  private UUID    jugador;
  
  private long    joc_id;
  private String  joc_nom;

  public TiradaN2DTO() { }  

  public TiradaN2DTO(UUID id, short dau1, short dau2, Timestamp dataTirada, UUID jugador,long joc_id,String joc_nom)
  { super();
    this.id = id;
    this.dau1 = dau1;
    this.dau2 = dau2;
    this.dataTirada = dataTirada;
    this.jugador = jugador;
    this.joc_id = joc_id;
    this.joc_nom = joc_nom;
  }

  public UUID getId() { return id; }
  public void setId(UUID id) { this.id = id; }

  public short getDau1() { return dau1; }
  public void setDau1(short dau1) { this.dau1 = dau1; }

  public short getDau2() { return dau2; }
  public void setDau2(short dau2) { this.dau2 = dau2; }

  public java.sql.Timestamp getDataTirada() { return dataTirada; }
  public void setDataTirada(java.sql.Timestamp dataTirada) { this.dataTirada = dataTirada; }

  public UUID getJugador() { return jugador; }
  public void setJugador(UUID jugador) { this.jugador = jugador; }
  
  public long getJoc_id() { return joc_id; }
  public void setJoc_id(long joc_id) { this.joc_id = joc_id; }

  public String getJoc_nom() { return joc_nom; }

  @Override
  public String toString() {
    return "TiradaN2DTO [id=" + id + ", dau1=" + dau1 + ", dau2=" + dau2 + ", dataTirada=" + dataTirada + ", jugador="
        + jugador + ", joc_id=" + joc_id + ", joc_nom=" + joc_nom + "]";
  }

  public void setJoc_nom(String joc_nom) { this.joc_nom = joc_nom; }  
  
  
}

