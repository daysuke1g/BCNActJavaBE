package zm16.service;

import java.util.Random;

import org.springframework.stereotype.Service;

@Service
public class ServiceOperations 
{ Random mRandomGenerator = null;
   
  public ServiceOperations()
  { mRandomGenerator = new Random();
  }
  
   public int tiraDau()
   { return (1+mRandomGenerator.nextInt(6)); 
   }
  
}
