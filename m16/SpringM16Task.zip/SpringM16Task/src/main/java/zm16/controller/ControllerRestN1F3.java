package zm16.controller; 

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import zm16.dao.PlayersN1F3DAO;
import zm16.dao.TiradesN1F3DAO;
import zm16.model.PlayerN1F3;
import zm16.model.PlayerN1F3DTO;
import zm16.model.TiradaN1F3;
import zm16.model.TiradaN1F3DTO;
import zm16.model.User;
import zm16.service.ServiceOperations;

@RestController            // Indica que esta clase va a ser un servicio RES                                     
@RequestMapping("/n1f3players")  // Indica la URL que se va a exponer los servicios de esta clase   
public class ControllerRestN1F3 
{
  
  @Autowired //Inyeccion de dependencias 
  private PlayersN1F3DAO mPlayersN1F3DAO;

  @Autowired //Inyeccion de dependencias  
  private TiradesN1F3DAO mTiradesN1F3DAO;
  
  @Autowired
  private ServiceOperations mServiceOperations; 
  
  //TEST curl -v http://localhost:8080/n1f3players/hello1
  @GetMapping("hello1")   
  public String hello() //@RequestMapping(value="", method=RequestMethod.GET) //En que url esta el servicio
  { return "hola amiguitos1!!"; 
  }

  
  //Aquest resource es l'unic disponible al path /n1f3players que es pot accedir sense identificacio
  //curl --request POST -L "http://localhost:8080/n1f3players/users?user=xxx&password=yyy"
  @PostMapping("/users")
  public User login(@RequestParam("user") String pUserNamename,@RequestParam("password") String pwd)
  { String token = getJWTToken(pUserNamename);
    User user = new User();
    user.setUser(pUserNamename);
    user.setPwd(""); // pwd
    user.setToken(token);
    return user;    
  }
  
  
  //GET /players:retorna el llistat de tots els jugadors del sistema amb el seu % mig d��xits   
  //TEST curl -v http://localhost:8080/n1f3players/players
  @GetMapping("players")   
  public ResponseEntity<List<PlayerN1F3DTO>> getPlayers() // Si lo encuentra retorna 200 sino 204
  { System.out.println("GET /n1f3players/players ----------------------------------------------");
    List<PlayerN1F3DTO> lPlayersDTO = new ArrayList<PlayerN1F3DTO>();
    List<PlayerN1F3> lPlayers = mPlayersN1F3DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1F3DTO(s.getId(),s.getNom(),s.getDataRegistre(), mTiradesN1F3DAO.calcSuccessPercent(s.getId()))
                                                     )
                               );        
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); }         
  }

  
  //POST: /players : crea un jugador
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"\"  }" http://localhost:8080/n1f3players/players
  //TEST Ja existeix un usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f3players/players
  //TEST Els jugadors amb nom anonim poden repetir-se
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"anonim\"  }" http://localhost:8080/n1f3players/players  
  //TEST Donar de alta
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Nom JugadorX\" } " http://localhost:8080/n1f3players/players
  @PostMapping("players")    
  public ResponseEntity<Object> create(@RequestBody PlayerN1F3 player)
  { System.out.println("POST /n1f3players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());

    // Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 

    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    {  PlayerN1F3 oldPlayer = mPlayersN1F3DAO.findFirst1ByNom(szNom); 
       if(oldPlayer!=null)
       { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix un usuari amb aquest nom",""));
       }
    }

    //Donar de alta l'usuari
    PlayerN1F3 newPlayer = mPlayersN1F3DAO.saveAndFlush(player);   //.save(player);
    System.out.println("Saved:"+newPlayer.toString());
    
    return ResponseEntity.ok(newPlayer);        
  }

  
  //PUT /players : modifica el nom del jugador 
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"\"  }" http://localhost:8080/n1f3players/players
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":100000 , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f3players/players
  //TEST Ja existeix un altre usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f3players/players
  //TEST Actualitzar
  //     curl --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"Jugador XXXXX\"  }" http://localhost:8080/n1f3players/players
  @PutMapping("players")    
  public ResponseEntity<Object> update(@RequestBody PlayerN1F3 player)
  { System.out.println("PUT /n1f3players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());
    //Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 
    
    Optional<PlayerN1F3> optPlayer = mPlayersN1F3DAO.findById(player.getId());
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+player.getId(),""));
    }
    
    PlayerN1F3 otherPlayer = mPlayersN1F3DAO.findFirst1ByNomAndIdNot(szNom,player.getId());
    if(otherPlayer!=null)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix altre jugador amb el mateix nom ("+otherPlayer.getId()+")",""));
    }
        
    PlayerN1F3 oldPlayerN1F3 = optPlayer.get();
    if(oldPlayerN1F3.getNom().trim().equals("szNom"))
    { return ResponseEntity.ok(oldPlayerN1F3);
    }
    
    oldPlayerN1F3.setNom(szNom);
    PlayerN1F3 updPlayer = mPlayersN1F3DAO.saveAndFlush(oldPlayerN1F3);
    
    return ResponseEntity.ok(updPlayer);        
  }


  //POST /players/{id}/games/ : un jugador espec�fic realitza una tirada dels daus.
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f3players/players/99999/games
  //TEST realitza tirada 
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f3players/players/4/games
  @PostMapping("/players/{id}/games")
  public ResponseEntity<Object> tirarDaus(@PathVariable("id") long pPlayerId)
  { System.out.println("PUT /players/{id}/games/ ---id:"+pPlayerId+"-------------------------------------------");

    Optional<PlayerN1F3> optPlayer = mPlayersN1F3DAO.findById(pPlayerId);
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+pPlayerId,""));
    }
  
    PlayerN1F3 jugador = optPlayer.get();
    TiradaN1F3 tirada = new TiradaN1F3();
    tirada.setDau1((short)mServiceOperations.tiraDau());
    tirada.setDau2((short)mServiceOperations.tiraDau());
    tirada.setPlayer(jugador);
    
    //Donar de alta l'usuari
    TiradaN1F3 newTirada = mTiradesN1F3DAO.saveAndFlush(tirada);
    //mTiradesN1F3DAO.findById(newTirada.getId());
    System.out.println("Saved:"+newTirada.toString());
  
    return ResponseEntity.ok(newTirada);
  }
  
  
  //DELETE /players/{id}/games: elimina les tirades del jugador
  //TEST curl -v --request DELETE http://localhost:8080/n1f3players/players/2/games
  @Transactional
  @RequestMapping(value="/players/{id}/games", method = RequestMethod.DELETE) 
  public ResponseEntity<Object> deleteByPlayer(@PathVariable("id") long pPlayerId)
  { System.out.println("DELETE /players/{id}/games ----Id:"+pPlayerId+"------------------------------------------");
    System.out.println("Ha borrar ----- > "+mTiradesN1F3DAO.countByPlayer(new PlayerN1F3(pPlayerId,"",null)));    
    int dNumRows =  mTiradesN1F3DAO.deleteByPlayer(new PlayerN1F3(pPlayerId,"",null));
    return ResponseEntity.ok("{ \"jugador_id\": " + pPlayerId + ", \"registres_esborrats\" : "+dNumRows+"}");
  }  
  


  //GET /players/{id}/games: retorna el llistat de jugades per un jugador.
  //TEST curl -v http://localhost:8080/n1f3players/players/1/games
  @GetMapping("/players/{id}/games")   
  public ResponseEntity<Object> getGames(@PathVariable long id)  
  { System.out.println("GET /players/{id}/games ----Id:"+id+"------------------------------------------");
    //Query1: Parametre = entitat 
    //List<TiradaN1> lTirades = mTiradesDAO.findByPlayer(new PlayerN1F3(id, "", null));
    //Query2: Joininig entities 
    List<TiradaN1F3> lTirades = mTiradesN1F3DAO.findByJugador(id);
    
    //Sense resposta retornar resposta buida 
    List<TiradaN1F3DTO> lTiradesDTO = new ArrayList<TiradaN1F3DTO>();
    if(lTirades!=null)
    { lTirades.stream().forEach( t -> lTiradesDTO.add(new TiradaN1F3DTO(t.getId(),t.getDau1(),t.getDau2(),t.getDataTirada(),id)));
    }    
    return ResponseEntity.ok(lTiradesDTO);
  }  
  
  
  //GET /players/ranking:retorna el ranking mig de tots els jugadors del sistema.�s a dir,el % mig d��xits.
  //TEST curl -v http://localhost:8080/n1f3players/players/ranking
  @GetMapping("/players/ranking")   
  public ResponseEntity<Object> getRanking()
  { System.out.println("GET /players/ranking-----------------------------------------");
    List<PlayerN1F3DTO> lPlayersDTO = new ArrayList<PlayerN1F3DTO>();
    List<PlayerN1F3> lPlayers = mPlayersN1F3DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream()
              .forEach(s->lPlayersDTO.add(new PlayerN1F3DTO(s.getId(),s.getNom(),s.getDataRegistre(), mTiradesN1F3DAO.calcSuccessPercent(s.getId()))));
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN1F3DTO::getPercentatgeExit).reversed());    
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); }   
    
    
  }  

  
  //GET /players/ranking/loser: retorna el jugador amb pitjor percentatge d��xit  
  //TEST curl -v -H "Content-Type: application/json" -H "Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJzb2Z0dGVrSldUIiwic3ViIjoieHh4IiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImlhdCI6MTYyOTkyNTU5MSwiZXhwIjoxNjI5OTMyNzkxfQ.RKXjR-gtuMAqBs5sCDl3gMb_keFzTlRJRC9uUpDgsiDPsvtJnnIqFLz9x9qU3XLI484H05bwczQmJDr_xT1R9A" --request GET http://localhost:8080/n1f3players/players/ranking/loser
  @GetMapping("/players/ranking/loser")   
  public ResponseEntity<PlayerN1F3DTO> getLosser() 
  { System.out.println("GET /players/ranking/loser-----------------------------------------"); 
    PlayerN1F3 loserPlayer = mPlayersN1F3DAO.getPrimSenseTirades();
    if(loserPlayer==null)
    { loserPlayer = mPlayersN1F3DAO.getPlayerMinTPC();      
    }
    if( loserPlayer==null ) { return ResponseEntity.noContent().build(); } 
       else 
       { PlayerN1F3DTO objRes = new PlayerN1F3DTO(loserPlayer.getId(),loserPlayer.getNom(),loserPlayer.getDataRegistre(), 
           mTiradesN1F3DAO.calcSuccessPercent(loserPlayer.getId()));
         return ResponseEntity.ok(objRes); 
       }         
  }
  

  //GET /players/ranking/winner: retorna el jugador amb pitjor percentatge d��xit 
  //TEST curl -v -H "Content-Type: application/json" -H "Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJzb2Z0dGVrSldUIiwic3ViIjoieHh4IiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImlhdCI6MTYyOTkyNTU5MSwiZXhwIjoxNjI5OTMyNzkxfQ.RKXjR-gtuMAqBs5sCDl3gMb_keFzTlRJRC9uUpDgsiDPsvtJnnIqFLz9x9qU3XLI484H05bwczQmJDr_xT1R9A" --request GET http://localhost:8080/n1f3players/players/ranking/winner    
  @GetMapping("/players/ranking/winner")   
  public ResponseEntity<PlayerN1F3DTO> getWinner() 
  { System.out.println("GET /players/ranking/winner-------------------------------------------");
    PlayerN1F3 winnerPlayer = mPlayersN1F3DAO.getPlayerMaxTCP();
    if( winnerPlayer==null ) { return ResponseEntity.noContent().build(); } 
       else 
       { PlayerN1F3DTO objRes = new PlayerN1F3DTO(winnerPlayer.getId(),winnerPlayer.getNom(),winnerPlayer.getDataRegistre(), 
                  mTiradesN1F3DAO.calcSuccessPercent(winnerPlayer.getId()));
         return ResponseEntity.ok(objRes); 
       }         
  }
  
 
  
  
  private String getJWTToken(String pUserName)
  { String secretKey = "mySecretKey";
    List<GrantedAuthority> grantedAuthirities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");
  
    String token = Jwts
              .builder()
              .setId("softtekJWT")
              .setSubject(pUserName)
              .claim("authorities",grantedAuthirities.stream()
                                                     .map(GrantedAuthority::getAuthority)
                                                     .collect(Collectors.toList()))
              .setIssuedAt(new Date(System.currentTimeMillis()))
              .setExpiration(new Date(System.currentTimeMillis()+(1000*3600*3)))
              .signWith(SignatureAlgorithm.HS512,secretKey.getBytes()).compact();    
    return "Bearer " + token; 
  }
}
