package zm16.controller; 

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import zm16.dao.PlayersN1F2DAO;
import zm16.dao.TiradesN1F2DAO;
import zm16.model.PlayerN1F2;
import zm16.model.PlayerN1F2DTO;
import zm16.model.TiradaN1F2;
import zm16.service.ServiceOperations;

@RestController            // Indica que esta clase va a ser un servicio RES                                     
@RequestMapping("/n1f2players")  // Indica la URL que se va a exponer los servicios de esta clase   
public class ControllerRestN1F2 
{
  //private java.text.SimpleDateFormat mSDFormatYearToSecond = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  
  @Autowired //Inyeccion de dependencias 
  private PlayersN1F2DAO mPlayersN1F2DAO;

  @Autowired //Inyeccion de dependencias  
  private TiradesN1F2DAO mTiradesN1F2DAO;
  //-----------------------------------------------

  @Autowired
  private ServiceOperations mServiceOperations; 

  //****************************************************************************************************************  
  //****************************************************************************************************************
  //****************************************************************************************************************
  /*@Autowired private LibroRepository repositorio;      
  @PostMapping("/inserta_libro") // curl -v --header "Content-Type: application/json" --request POST --data "{ \"id\": 0, \"nombre\" : \"AAA\" , \"autor\" : \"AAA\", \"editorial\" : \"BBB\" }"  http://localhost:8080/n1f2players/inserta_libro 
  public String saveBook(@RequestBody Libro pLibro)
  { repositorio.save(pLibro);
    return "Insertado libro : " + pLibro.getId() + " - " + pLibro.getNombre();    
  }
  @GetMapping("/get_libros") // curl -v http://localhost:8080/n1f2players/get_libros
  public List<Libro> getBooks()
  { List<Libro>   lista = repositorio.findAll();
    return lista;
  } */ 
  //****************************************************************************************************************  
  //****************************************************************************************************************
  //****************************************************************************************************************
  
  //TEST curl -v http://localhost:8080/n1f2players/hello1
  @GetMapping("hello1")   
  public String hello() //@RequestMapping(value="", method=RequestMethod.GET) //En que url esta el servicio
  { return "hola amiguitos1!!";
  }
  
  
  
  //GET /players:retorna el llistat de tots els jugadors del sistema amb el seu % mig d��xits   
  //TEST curl -v http://localhost:8080/n1f2players/players 
  @GetMapping("players")   
  public ResponseEntity<List<PlayerN1F2DTO>> getPlayers() // Si lo encuentra retorna 200 sino 204
  { System.out.println("GET /n1f2players/players ----------------------------------------------");

    List<PlayerN1F2> lPlayers = mPlayersN1F2DAO.findAll();
    if(lPlayers==null) { return ResponseEntity.noContent().build(); } 
    //System.out.println(">>>>>>>" + calcSuccessTPCByPlayer(1));
    
    List<PlayerN1F2DTO> lPlayersDTO = new ArrayList<PlayerN1F2DTO>();
    if(lPlayers!=null)
    { lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1F2DTO(s.getId(),s.getNom(),s.getData_registre(), calcSuccessTPCByPlayer(s.getId()) ) )
                               );        
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) 
    { lPlayersDTO.stream().forEach( s -> System.out.println(s.toString()) ); 
      return ResponseEntity.ok(lPlayersDTO); 
    } 
 
    return ResponseEntity.noContent().build();
  }

  
  //POST: /players : crea un jugador
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"\"  }" http://localhost:8080/n1f2players/players
  //TEST Ja existeix un usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"anonim2\"  }" http://localhost:8080/n1f2players/players
  //TEST Els jugadors amb nom anonim poden repetir-se
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"anonim\"  }" http://localhost:8080/n1f2players/players  
  //TEST Donar de alta
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Nom JugadorX\" } " http://localhost:8080/n1f2players/players
  @PostMapping("players")    
  public ResponseEntity<Object> create(@RequestBody PlayerN1F2 playerToInsert)
  { System.out.println("POST /n1f2players/players ----------------------------------------------");
    System.out.println("Input:"+playerToInsert.toString());
    
    // Si el nom  no esta informat .... 
    String szNom = playerToInsert.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 

    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    {  PlayerN1F2 oldPlayer = mPlayersN1F2DAO.findFirst1ByNom(szNom); 
       if(oldPlayer!=null)
       { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix un usuari amb aquest nom",""));
       }
    }
    
    if(mPlayersN1F2DAO.count()==0) { playerToInsert.setId(0); }
      else { playerToInsert.setId(mPlayersN1F2DAO.getMaxId()+1); } //Obtenir el valor maxim _id    
    playerToInsert.setData_registre(Calendar.getInstance().getTime());
        
    PlayerN1F2 newPlayer = mPlayersN1F2DAO.save(playerToInsert);  //Donar de alta l'usuari 
     
    return ResponseEntity.ok(newPlayer);
  }

  
  //PUT /players : modifica el nom del jugador 
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"\"  }" http://localhost:8080/n1f2players/players
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":100000 , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f2players/players
  //TEST Ja existeix un altre usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"Nom JugadorX2\"  }" http://localhost:8080/n1f2players/players
  //TEST Actualitzar el nom
  //     curl --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"1111111\"  }" http://localhost:8080/n1f2players/players
  @PutMapping("players")    
  public ResponseEntity<Object> update(@RequestBody PlayerN1F2 player)
  { System.out.println("PUT /n1f2players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());
    //Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 
    
    Optional<PlayerN1F2> optPlayer = mPlayersN1F2DAO.findById(player.getId());
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+player.getId(),""));
    }

    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    { PlayerN1F2 otherPlayer = mPlayersN1F2DAO.findFirst1ByNomAndIdNot(szNom,player.getId());
      if(otherPlayer!=null)
      { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix altre jugador amb el mateix nom ("+otherPlayer.getId()+")",""));
      }
    }
    
    PlayerN1F2 oldPlayerN1F2 = optPlayer.get();
    if(oldPlayerN1F2.getNom().trim().equals("szNom"))
    { return ResponseEntity.ok(oldPlayerN1F2);
    }
    
    oldPlayerN1F2.setNom(szNom);
    PlayerN1F2 updPlayer = mPlayersN1F2DAO.save(oldPlayerN1F2);
    return ResponseEntity.ok(updPlayer);
    
    //return ResponseEntity.noContent().build();     
  }

 
  //POST /players/{id}/games/ : un jugador espec�fic realitza una tirada dels daus.  
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f2players/players/99999/games
  //TEST realitza tirada 
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f2players/players/1/games
  @PostMapping("/players/{id}/games")
  public ResponseEntity<Object> tirarDaus(@PathVariable("id") long pPlayerId)
  { System.out.println("PUT /players/{id}/games/ ---id:"+pPlayerId+"-------------------------------------------");

    Optional<PlayerN1F2> optPlayer = mPlayersN1F2DAO.findById(pPlayerId);
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+pPlayerId,""));
    }
    PlayerN1F2 jugador = optPlayer.get();
    
    TiradaN1F2 tirada = new TiradaN1F2();
    if(mTiradesN1F2DAO.count()==0) { tirada.setId(0); }
    else { tirada.setId(mTiradesN1F2DAO.getMaxId()+1); }   //Obtenir el valor maxim _id    
    tirada.setDau1((short)mServiceOperations.tiraDau());
    tirada.setDau2((short)mServiceOperations.tiraDau());
    tirada.setPlayer(jugador.getId());
    tirada.setDataTirada(Calendar.getInstance().getTime());

    //Donar de alta l'usuari
    TiradaN1F2 newTirada = mTiradesN1F2DAO.save(tirada);
    System.out.println("Saved:"+newTirada.toString());
    
    //mTiradesDAO.findById(newTirada.getId());
    //System.out.println("Saved2:"+newTirada.toString());

    return ResponseEntity.ok(newTirada);
    //return ResponseEntity.noContent().build(); 
  }
  
  
  //DELETE /players/{id}/games: elimina les tirades del jugador
  // Carregar tirades per a esborrar    curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f2players/players/3/games
  //TEST curl -v --request DELETE http://localhost:8080/n1f2players/players/3/games
  //@Transactional
  @RequestMapping(value="/players/{id}/games", method = RequestMethod.DELETE) 
  public ResponseEntity<Object> deleteByPlayer(@PathVariable("id") long pPlayerId)
  { System.out.println("DELETE /players/{id}/games ----Id:"+pPlayerId+"------------------------------------------");
    System.out.println("Ha borrar ----- > "+mTiradesN1F2DAO.countByJugador(pPlayerId));    
    int dNumRows =  mTiradesN1F2DAO.deleteByJugador(pPlayerId);
    return ResponseEntity.ok("{ \"jugador_id\": " + pPlayerId + ", \"registres_esborrats\" : "+dNumRows+"}");
    //return ResponseEntity.noContent().build();     
  }  

  
  
  //GET /players/{id}/games: retorna el llistat de jugades per un jugador.
  //TEST curl -v --request GET http://localhost:8080/n1f2players/players/1/games
  @GetMapping("/players/{id}/games")  
  public ResponseEntity<Object> getGames(@PathVariable long id)  
  { System.out.println("GET /players/{id}/games ----Id:"+id+"------------------------------------------"); 
    //Query1: Parametre = entitat 
    //List<TiradaN1> lTirades = mTiradesDAO.findByPlayer(new PlayerN1F2(id, "", null));
    List<TiradaN1F2> lTirades = mTiradesN1F2DAO.findByJugador(id);
    if(lTirades==null) return ResponseEntity.noContent().build();     
    return ResponseEntity.ok(lTirades);  
  }
  
  

  ////GET /players/ranking:retorna el ranking mig de tots els jugadors del sistema.�s a dir,el % mig d��xits.
  //TEST curl -v http://localhost:8080/n1f2players/players/ranking
  @GetMapping("/players/ranking")   
  public ResponseEntity<Object> getRanking()
  { System.out.println("GET /players/ranking-----------------------------------------");
  
    List<PlayerN1F2DTO> lPlayersDTO = new ArrayList<PlayerN1F2DTO>();
    List<PlayerN1F2> lPlayers = mPlayersN1F2DAO.findAll(); // Obtenir Jugadors
    if(lPlayers!=null)
    { //Afegir % d'exit  
      lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1F2DTO(s.getId(),s.getNom(),s.getData_registre(), calcSuccessTPCByPlayer(s.getId()) ) ) );
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN1F2DTO::getPercentatgeExit).reversed()); //Ordenar per % descendent
    } 
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); }  
    return ResponseEntity.noContent().build();   
  }


  
  //GET /players/ranking/loser: retorna el jugador amb pitjor percentatge d��xit  
  //TEST curl -v http://localhost:8080/n1f2players/players/ranking/loser
  @GetMapping("/players/ranking/loser")   
  public ResponseEntity<PlayerN1F2DTO> getLosser() 
  { System.out.println("GET /players/ranking/loser-----------------------------------------");
  
    List<PlayerN1F2DTO> lPlayersDTO = new ArrayList<PlayerN1F2DTO>();
    List<PlayerN1F2> lPlayers = mPlayersN1F2DAO.findAll(); // Obtenir Jugadors
    if(lPlayers!=null)
    { //Afegir % d'exit  
      lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1F2DTO(s.getId(),s.getNom(),s.getData_registre(), calcSuccessTPCByPlayer(s.getId()) ) ) );
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN1F2DTO::getPercentatgeExit)); //Ordenar per % 
    } 
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) )
    { return ResponseEntity.ok(lPlayersDTO.get(0)); 
    }  
    return ResponseEntity.noContent().build();    
  }

  
   
  //GET /players/ranking/winner: retorna el jugador amb pitjor percentatge d��xit 
  //TEST curl -v http://localhost:8080/n1f2players/players/ranking/winner
  @GetMapping("/players/ranking/winner")   
  public ResponseEntity<PlayerN1F2DTO> getWinner() 
  { System.out.println("GET /players/ranking/winner-----------------------------------------");    
    List<PlayerN1F2DTO> lPlayersDTO = new ArrayList<PlayerN1F2DTO>();
    List<PlayerN1F2> lPlayers = mPlayersN1F2DAO.findAll(); // Obtenir Jugadors
    if(lPlayers!=null)
    { //Afegir % d'exit  
      lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1F2DTO(s.getId(),s.getNom(),s.getData_registre(), calcSuccessTPCByPlayer(s.getId()) ) ) );
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN1F2DTO::getPercentatgeExit).reversed()); //Ordenar per % descendent
    } 
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) )
    { return ResponseEntity.ok(lPlayersDTO.get(0)); 
    }  
    return ResponseEntity.noContent().build();       
  }
  
 
  
  // Retorna el % d'exit per a un jugador
  private float calcSuccessTPCByPlayer(long pIdPlayer)
  { float poSuccessTPC = 0;
    
    WrapperCounter00  objWC00 = new WrapperCounter00();    
    List<TiradaN1F2> lTirada = mTiradesN1F2DAO.findByJugador(pIdPlayer);
    if(lTirada!=null)
    { objWC00.init();
      lTirada.stream() 
             .forEach( s ->  { if( (s.getDau1()+s.getDau2()) == 7 ) { objWC00.dTotal7s++ ; }    
                               objWC00.dTotal++;
                             } 
                     );
      poSuccessTPC = ((float)objWC00.dTotal7s/(float)objWC00.dTotal )*100;  
      poSuccessTPC = ((float)((int)(poSuccessTPC*100))/100); // redondeo a 2 decimales      
    }
    return poSuccessTPC;
  }
  
  class WrapperCounter00  
  { public int dTotal = 0; 
    public int dTotal7s = 0 ;
    public void init()
    { dTotal=0;
      dTotal7s=0;
    }
    
  };
}
