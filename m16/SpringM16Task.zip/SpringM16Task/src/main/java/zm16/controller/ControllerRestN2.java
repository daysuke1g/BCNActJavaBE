package zm16.controller; 

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import zm16.dao.JocsN2DAO;
import zm16.dao.PlayersN2DAO;
import zm16.dao.TiradesN2DAO;
import zm16.model.JocN2;
import zm16.model.PlayerN2;
import zm16.model.PlayerN2DTO;
import zm16.model.TiradaN2;
import zm16.model.TiradaN2DTO;
import zm16.service.ServiceOperations;

@RestController            // Indica que esta clase va a ser un servicio RES                                     
@RequestMapping("/n2players")  // Indica la URL que se va a exponer los servicios de esta clase   
public class ControllerRestN2 
{
  @Autowired //Inyeccion de dependencias 
  private PlayersN2DAO mPlayersN2DAO;

  @Autowired //Inyeccion de dependencias  
  private TiradesN2DAO mTiradesDAO;
  
  @Autowired
  private JocsN2DAO mJocsN2DAO;
  
  @Autowired
  private ServiceOperations mServiceOperations; 
  
  //TEST curl -v http://localhost:8080/n2players/hello1
  @GetMapping("hello1")   
  public String hello() //@RequestMapping(value="", method=RequestMethod.GET) //En que url esta el servicio
  { return "hola amiguitos n2players 1!!";
  }

    
  //GET /players:retorna el llistat de tots els jugadors del sistema amb el seu % mig d��xits   
  //TEST curl -v http://localhost:8080/n2players/players
  @GetMapping("players")   
  public ResponseEntity<List<PlayerN2DTO>> getPlayers() // Si lo encuentra retorna 200 sino 204
  { System.out.println("GET /n2players/players ----------------------------------------------");
    List<PlayerN2DTO> lPlayersDTO = new ArrayList<PlayerN2DTO>();
      
    List<PlayerN2> lPlayers = mPlayersN2DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN2DTO(s.getId(),s.getNom(),s.getAnonim(), s.getDataRegistre(), mTiradesDAO.calcSuccessPercent(s.getId().toString()))
                                                     )
                               );        
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); } 
  }

    
  //POST: /players : crea un jugador
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"\"  }" http://localhost:8080/n2players/players
  //TEST Ja existeix un usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Jugador 1\" , \"anonim\":\"N\" }" http://localhost:8080/n2players/players
  //TEST Els jugadors no es poden dir anonim
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"anonim\" , \"anonim\":\"N\" }" http://localhost:8080/n2players/players  
  //TEST Donar de alta
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Nom JugadorX\" , \"anonim\":\"N\" } " http://localhost:8080/n2players/players
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Nom JugadorY\" , \"anonim\":\"S\" } " http://localhost:8080/n2players/players  
  @PostMapping("players")    
  public ResponseEntity<Object> create(@RequestBody PlayerN2 player)
  { System.out.println("POST /n2players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());

    // Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null)?"":szNom.trim();
    if(szNom.equalsIgnoreCase(""))  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    }
    else if(szNom.equalsIgnoreCase("anonim"))
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"'"+player.getNom()+"' No es un nom correcte",""));
    }
    
    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    { PlayerN2 oldPlayer = mPlayersN2DAO.findFirst1ByNom(szNom); 
      if(oldPlayer!=null)
      { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix un usuari amb aquest nom",""));
      }
    }

    //Donar de alta l'usuari
    PlayerN2 newPlayer = mPlayersN2DAO.saveAndFlush(player);   //.save(player);
    System.out.println("Saved:"+newPlayer.toString());
    
    return ResponseEntity.ok(newPlayer);
  }
   

  //PUT /players : modifica el nom del jugador   Get per llegir Ids curl -v http://localhost:8080/n2players/players
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":\"66353863-3232-6430-2d30-3531642d3131\" , \"nom\" : \"\", \"anonim\":\"N\"  }" http://localhost:8080/n2players/players
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":\"66353863-3232-6430-2d30-3531642d9999\" , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n2players/players
  //TEST Ja existeix un altre usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":\"96503c12-0523-11ec-adf3-3c970e199bd2\" , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n2players/players
  //TEST Actualiztar 
  //     curl --header "Content-Type: application/json" --request PUT --data "{ \"id\":\"96503c12-0523-11ec-adf3-3c970e199bd2\" , \"nom\" : \"Jugador XXXXX\"  }" http://localhost:8080/n2players/players
  //     curl --header "Content-Type: application/json" --request PUT --data "{ \"id\":\"96b87548-0523-11ec-adf3-3c970e199bd2\" , \"nom\" : \"Jugador YYYYY\"  }" http://localhost:8080/n2players/players  
  @PutMapping("players")    
  public ResponseEntity<Object> update(@RequestBody PlayerN2 player)
  { System.out.println("PUT /n2players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());
    //Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 
           
    Optional<PlayerN2> optPlayer = mPlayersN2DAO.findById(player.getId());
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+player.getId(),""));
    }

    PlayerN2 otherPlayer = mPlayersN2DAO.findFirst1ByNomAndIdNot(szNom,player.getId());
    if(otherPlayer!=null)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix altre jugador amb el mateix nom ("+otherPlayer.getId()+")",""));
    }
    
    PlayerN2 oldPlayerN2 = optPlayer.get();
    if(oldPlayerN2.getNom().trim().equals("szNom"))
    { return ResponseEntity.ok(oldPlayerN2);
    }
    oldPlayerN2.setNom(szNom);
    PlayerN2 updPlayer = mPlayersN2DAO.saveAndFlush(oldPlayerN2); 
    
    return ResponseEntity.ok(updPlayer);    
  }

  
  
  
  //POST /players/{id}/games/ : un jugador espec�fic realitza una tirada dels daus.   Get per llegir Ids curl -v http://localhost:8080/n2players/players
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n2players/players/8b29aff4-0526-11ec-adf3-3c970e111112/games
  //TEST realitza tirada 
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n2players/players/0c6b379b-05f1-11ec-b03e-3c970e199bd2/games/1
  @PostMapping("/players/{id}/games/{pIdJoc}")
  public ResponseEntity<Object> tirarDaus(@PathVariable("id") UUID pPlayerId,@PathVariable("pIdJoc") long pIdJoc)
  { System.out.println("PUT /players/{id}/games/ ---id:"+pPlayerId+"-------------------------------------------");

    Optional<PlayerN2> optPlayer = mPlayersN2DAO.findById(pPlayerId);
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+pPlayerId,""));
    }
  
    Optional<JocN2> optJoc = mJocsN2DAO.findById(pIdJoc);
    if(optJoc.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix el joc:"+pIdJoc,""));
    }
    
    PlayerN2 jugador = optPlayer.get(); 
    JocN2    joc = optJoc.get();
    
    TiradaN2 tirada = new TiradaN2();
    tirada.setDau1((short)mServiceOperations.tiraDau());
    tirada.setDau2((short)mServiceOperations.tiraDau());
    tirada.setPlayer(jugador);
    tirada.setJoc(joc);

    //Donar de alta l'usuari
    TiradaN2 newTirada = mTiradesDAO.saveAndFlush(tirada);
    System.out.println("Saved:"+newTirada.toString());
    
    //mTiradesDAO.findById(newTirada.getId());
    //System.out.println("Saved2:"+newTirada.toString());
  
    return ResponseEntity.ok(newTirada);
  }

  
  
  //DELETE /players/{id}/games: elimina les tirades del jugador
  //TEST curl -v --request DELETE http://localhost:8080/n2players/players/0c6b379b-05f1-11ec-b03e-3c970e199bd2/games
  @Transactional
  @RequestMapping(value="/players/{id}/games", method = RequestMethod.DELETE) 
  public ResponseEntity<Object> deleteByPlayer(@PathVariable("id") UUID pPlayerId)
  { System.out.println("DELETE /players/{id}/games ----Id:"+pPlayerId+"------------------------------------------");
    PlayerN2 p = new PlayerN2(pPlayerId,"","N",null);
    System.out.println("Ha borrar ----- > "+mTiradesDAO.countByPlayer(p));    
    int dNumRows =  mTiradesDAO.deleteByPlayer(p);
    return ResponseEntity.ok("{ \"jugador_id\": " + pPlayerId + ", \"registres_esborrats\" : "+dNumRows+"}");
  }  
  

  
  //GET /players/{id}/games: retorna el llistat de jugades per un jugador.    Get per llegir Ids curl -v http://localhost:8080/n2players/players
  //      Fer tirada              curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n2players/players/08222e72-052d-11ec-adf3-3c970e199bd2/games
  //TEST curl -v http://localhost:8080/n2players/players/0c6b379b-05f1-11ec-b03e-3c970e199bd2/games
  @GetMapping("/players/{id}/games")   
  public ResponseEntity<Object> getGames(@PathVariable UUID id)  
  { System.out.println("GET /players/{id}/games ----Id:"+id+"------------------------------------------");
    //Query1: Parametre = entitat 
    //List<TiradaN2> lTirades = mTiradesDAO.findByPlayer(new PlayerN2(id, "", null));
    //Query2: Joininig entities 
    List<TiradaN2> lTirades = mTiradesDAO.findByJugador(id);
    
    //Sense resposta retornar resposta buida 
    List<TiradaN2DTO> lTiradesDTO = new ArrayList<TiradaN2DTO>();
    if(lTirades!=null)
    { lTirades.stream().forEach( t -> lTiradesDTO.add(new TiradaN2DTO(t.getId(),t.getDau1(),t.getDau2(),t.getDataTirada(),id,t.getJoc().getId(),t.getJoc().getNom()))); 
    }   
    
    lTiradesDTO.stream().forEach( s -> System.out.println(s.toString()) ); 
    
    return ResponseEntity.ok(lTiradesDTO);
  }
  

  ////GET /players/ranking:retorna el ranking mig de tots els jugadors del sistema.�s a dir,el % mig d��xits.
  //TEST curl -v http://localhost:8080/n2players/players/ranking
  @GetMapping("/players/ranking")   
  public ResponseEntity<Object> getRanking()
  { System.out.println("GET /players/ranking-----------------------------------------");
  
    List<PlayerN2DTO> lPlayersDTO = new ArrayList<PlayerN2DTO>();
    List<PlayerN2> lPlayers = mPlayersN2DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream()
              .forEach(s->lPlayersDTO.add(new PlayerN2DTO(s.getId(),s.getNom(),s.getAnonim(),s.getDataRegistre(), mTiradesDAO.calcSuccessPercent(s.getId().toString()))));
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN2DTO::getPercentatgeExit).reversed());    
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); }  
  }
  
  

  //GET /players/ranking/loser: retorna el jugador amb pitjor percentatge d��xit   
  //TEST curl -v http://localhost:8080/n2players/players/ranking/loser
  @GetMapping("/players/ranking/loser")   
  public ResponseEntity<PlayerN2DTO> getLosser() 
  { System.out.println("GET /players/ranking/loser-----------------------------------------");  
    PlayerN2 loserPlayer = mPlayersN2DAO.getPrimSenseTirades();
    if(loserPlayer==null)
    { loserPlayer = mPlayersN2DAO.getPlayerMinTPC();       
    }
    if( loserPlayer==null ) { return ResponseEntity.noContent().build(); } 
    else 
    { PlayerN2DTO objRes = new PlayerN2DTO(loserPlayer.getId(),loserPlayer.getNom(),loserPlayer.getAnonim(),loserPlayer.getDataRegistre(), 
                                           mTiradesDAO.calcSuccessPercent(loserPlayer.getId().toString()));
      return ResponseEntity.ok(objRes); 
    }         
  }
  
  
  //GET /players/ranking/winner: retorna el jugador amb pitjor percentatge d��xit 
  //TEST curl -v http://localhost:8080/n2players/players/ranking/winner
  @GetMapping("/players/ranking/winner")   
  public ResponseEntity<PlayerN2DTO> getWinner() 
  { System.out.println("GET /players/ranking/winner-------------------------------------------");
    PlayerN2 winnerPlayer = mPlayersN2DAO.getPlayerMaxTCP();
    if( winnerPlayer==null ) { return ResponseEntity.noContent().build(); } 
       else 
       { PlayerN2DTO objRes = new PlayerN2DTO(winnerPlayer.getId(),winnerPlayer.getNom(),winnerPlayer.getAnonim(),winnerPlayer.getDataRegistre(), 
                                              mTiradesDAO.calcSuccessPercent(winnerPlayer.getId().toString()));
         return ResponseEntity.ok(objRes); 
       }         
  }
  
 
}
