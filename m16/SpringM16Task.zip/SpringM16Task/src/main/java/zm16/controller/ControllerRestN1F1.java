package zm16.controller; 

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import zm16.dao.PlayersN1DAO;
import zm16.dao.TiradesN1DAO;
import zm16.model.PlayerN1;
import zm16.model.PlayerN1DTO;
import zm16.model.TiradaN1;
import zm16.model.TiradaN1DTO;
import zm16.service.ServiceOperations;

@RestController            // Indica que esta clase va a ser un servicio RES                                     
@RequestMapping("/n1f1players")  // Indica la URL que se va a exponer los servicios de esta clase   
public class ControllerRestN1F1 
{
  @Autowired //Inyeccion de dependencias 
  private PlayersN1DAO mPlayersN1DAO;

  @Autowired //Inyeccion de dependencias  
  private TiradesN1DAO mTiradesDAO;
  
  @Autowired
  private ServiceOperations mServiceOperations; 
  
  //TEST curl -v http://localhost:8080/n1f1players/hello1
  @GetMapping("hello1")   
  public String hello() //@RequestMapping(value="", method=RequestMethod.GET) //En que url esta el servicio
  { return "hola amiguitos1!!";
  }
  
  //GET /players:retorna el llistat de tots els jugadors del sistema amb el seu % mig d��xits   
  //TEST curl -v http://localhost:8080/n1f1players/players
  @GetMapping("players")   
  public ResponseEntity<List<PlayerN1DTO>> getPlayers() // Si lo encuentra retorna 200 sino 204
  { System.out.println("GET /n1f1players/players ----------------------------------------------");
    List<PlayerN1DTO> lPlayersDTO = new ArrayList<PlayerN1DTO>();
    List<PlayerN1> lPlayers = mPlayersN1DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream().forEach( s -> lPlayersDTO.add(new PlayerN1DTO(s.getId(),s.getNom(),s.getDataRegistre(), mTiradesDAO.calcSuccessPercent(s.getId()))
                                                     )
                               );        
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); }         
  }

  
  //POST: /players : crea un jugador
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"\"  }" http://localhost:8080/n1f1players/players
  //TEST Ja existeix un usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f1players/players
  //TEST Els jugadors amb nom anonim poden repetir-se
  //     curl -v --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"anonim\"  }" http://localhost:8080/n1f1players/players  
  //TEST Donar de alta
  //     curl --header "Content-Type: application/json" --request POST --data "{ \"nom\" : \"Nom JugadorX\" } " http://localhost:8080/n1f1players/players
  @PostMapping("players")    
  public ResponseEntity<Object> create(@RequestBody PlayerN1 player)
  { System.out.println("POST /n1f1players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());

    // Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 

    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    {  PlayerN1 oldPlayer = mPlayersN1DAO.findFirst1ByNom(szNom); 
       if(oldPlayer!=null)
       { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix un usuari amb aquest nom",""));
       }
    }

    //Donar de alta l'usuari
    PlayerN1 newPlayer = mPlayersN1DAO.saveAndFlush(player);   //.save(player);
    System.out.println("Saved:"+newPlayer.toString());
    
    return ResponseEntity.ok(newPlayer);        
  }

  
  //PUT /players : modifica el nom del jugador 
  //TEST Error cal informar nom 
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"\"  }" http://localhost:8080/n1f1players/players
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":100000 , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f1players/players
  //TEST Ja existeix un altre usuari amb aquest nom
  //     curl -v --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"Jugador 1\"  }" http://localhost:8080/n1f1players/players
  //TEST Donar de alta
  //     curl --header "Content-Type: application/json" --request PUT --data "{ \"id\":1 , \"nom\" : \"Jugador XXXXX\"  }" http://localhost:8080/n1f1players/players
  @PutMapping("players")    
  public ResponseEntity<Object> update(@RequestBody PlayerN1 player)
  { System.out.println("PUT /n1f1players/players ----------------------------------------------");
    System.out.println("Input:"+player.toString());
    //Si el nom  no esta informat .... 
    String szNom = player.getNom();
    szNom = (szNom==null) ? "":szNom.trim();
    if( szNom.equalsIgnoreCase("") )  
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Cal informar el nom",""));                      
    } 
    
    Optional<PlayerN1> optPlayer = mPlayersN1DAO.findById(player.getId());
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+player.getId(),""));
    }
    
    if(!szNom.equalsIgnoreCase("ANONIM")) // Control repetit si no es anonim 
    { PlayerN1 otherPlayer = mPlayersN1DAO.findFirst1ByNomAndIdNot(szNom,player.getId());
      if(otherPlayer!=null)
      { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"Ja existeix altre jugador amb el mateix nom ("+otherPlayer.getId()+")",""));
      }
    }
        
    PlayerN1 oldPlayerN1 = optPlayer.get();
    if(oldPlayerN1.getNom().trim().equals("szNom"))
    { return ResponseEntity.ok(oldPlayerN1);
    }
    
    oldPlayerN1.setNom(szNom);
    PlayerN1 updPlayer = mPlayersN1DAO.saveAndFlush(oldPlayerN1);
    
    return ResponseEntity.ok(updPlayer);        
  }

  
  //POST /players/{id}/games/ : un jugador espec�fic realitza una tirada dels daus.
  //TEST No existeix un jugador amb aquest Id
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f1players/players/99999/games
  //TEST realitza tirada 
  //     curl -v --header "Content-Type: application/json" --request POST http://localhost:8080/n1f1players/players/4/games
  @PostMapping("/players/{id}/games")
  public ResponseEntity<Object> tirarDaus(@PathVariable("id") long pPlayerId)
  { System.out.println("PUT /players/{id}/games/ ---id:"+pPlayerId+"-------------------------------------------");

    Optional<PlayerN1> optPlayer = mPlayersN1DAO.findById(pPlayerId);
    if(optPlayer.isPresent()==false)
    { return ResponseEntity.badRequest().body(new ApiError(HttpStatus.BAD_REQUEST,"No existeix un jugador amb Id:"+pPlayerId,""));
    }
    
    PlayerN1 jugador = optPlayer.get();
    TiradaN1 tirada = new TiradaN1();
    tirada.setDau1((short)mServiceOperations.tiraDau());
    tirada.setDau2((short)mServiceOperations.tiraDau());
    tirada.setPlayer(jugador);
    
    //Donar de alta l'usuari
    TiradaN1 newTirada = mTiradesDAO.saveAndFlush(tirada);
    System.out.println("Saved:"+newTirada.toString());
    
    //mTiradesDAO.findById(newTirada.getId());
    //System.out.println("Saved2:"+newTirada.toString());
  
    return ResponseEntity.ok(newTirada);
  }
  
  
  //DELETE /players/{id}/games: elimina les tirades del jugador
  //TEST curl -v --request DELETE http://localhost:8080/n1f1players/players/2/games
  @Transactional
  @RequestMapping(value="/players/{id}/games", method = RequestMethod.DELETE) 
  public ResponseEntity<Object> deleteByPlayer(@PathVariable("id") long pPlayerId)
  { System.out.println("DELETE /players/{id}/games ----Id:"+pPlayerId+"------------------------------------------");
    System.out.println("Ha borrar ----- > "+mTiradesDAO.countByPlayer(new PlayerN1(pPlayerId,"",null)));    
    int dNumRows =  mTiradesDAO.deleteByPlayer(new PlayerN1(pPlayerId,"",null));
    return ResponseEntity.ok("{ \"jugador_id\": " + pPlayerId + ", \"registres_esborrats\" : "+dNumRows+"}");
  }  
  
  
  //GET /players/{id}/games: retorna el llistat de jugades per un jugador.
  //TEST curl -v http://localhost:8080/n1f1players/players/1/games
  @GetMapping("/players/{id}/games")   
  public ResponseEntity<Object> getGames(@PathVariable long id)  
  { System.out.println("GET /players/{id}/games ----Id:"+id+"------------------------------------------");
    //Query1: Parametre = entitat 
    //List<TiradaN1> lTirades = mTiradesDAO.findByPlayer(new PlayerN1(id, "", null));
    //Query2: Joininig entities 
    List<TiradaN1> lTirades = mTiradesDAO.findByJugador(id);
    
    //Sense resposta retornar resposta buida 
    List<TiradaN1DTO> lTiradesDTO = new ArrayList<TiradaN1DTO>();
    if(lTirades!=null)
    { lTirades.stream().forEach( t -> lTiradesDTO.add(new TiradaN1DTO(t.getId(),t.getDau1(),t.getDau2(),t.getDataTirada(),id)));
    }    
    return ResponseEntity.ok(lTiradesDTO);
  }
  

  ////GET /players/ranking:retorna el ranking mig de tots els jugadors del sistema.�s a dir,el % mig d��xits.
  //TEST curl -v http://localhost:8080/n1f1players/players/ranking
  @GetMapping("/players/ranking")   
  public ResponseEntity<Object> getRanking()
  { System.out.println("GET /players/ranking-----------------------------------------");
    List<PlayerN1DTO> lPlayersDTO = new ArrayList<PlayerN1DTO>();
    List<PlayerN1> lPlayers = mPlayersN1DAO.findAll();
    if(lPlayers!=null)
    { lPlayers.stream()
              .forEach(s->lPlayersDTO.add(new PlayerN1DTO(s.getId(),s.getNom(),s.getDataRegistre(), mTiradesDAO.calcSuccessPercent(s.getId()))));
      Collections.sort(lPlayersDTO,Comparator.comparing(PlayerN1DTO::getPercentatgeExit).reversed());    
    }
    if( (lPlayersDTO!=null) && ( lPlayersDTO.size()> 0 ) ) { return ResponseEntity.ok(lPlayersDTO); } 
       else { return ResponseEntity.noContent().build(); }   
  }
  
  
  //GET /players/ranking/loser: retorna el jugador amb pitjor percentatge d��xit   
  //TEST curl -v http://localhost:8080/n1f1players/players/ranking/loser
  @GetMapping("/players/ranking/loser")   
  public ResponseEntity<PlayerN1DTO> getLosser() 
  { System.out.println("GET /players/ranking/loser-----------------------------------------");  
    PlayerN1 loserPlayer = mPlayersN1DAO.getPrimSenseTirades();
    if(loserPlayer==null)
    { loserPlayer = mPlayersN1DAO.getPlayerMinTPC();       
    }
    if( loserPlayer==null ) { return ResponseEntity.noContent().build(); } 
    else 
    { PlayerN1DTO objRes = new PlayerN1DTO(loserPlayer.getId(),loserPlayer.getNom(),loserPlayer.getDataRegistre(), 
                                           mTiradesDAO.calcSuccessPercent(loserPlayer.getId()));
      return ResponseEntity.ok(objRes); 
    }         
  }
  
  
  //GET /players/ranking/winner: retorna el jugador amb pitjor percentatge d��xit 
  //TEST curl -v http://localhost:8080/n1f1players/players/ranking/winner
  @GetMapping("/players/ranking/winner")   
  public ResponseEntity<PlayerN1DTO> getWinner() 
  { System.out.println("GET /players/ranking/winner-------------------------------------------");
    PlayerN1 winnerPlayer = mPlayersN1DAO.getPlayerMaxTCP();
    if( winnerPlayer==null ) { return ResponseEntity.noContent().build(); } 
       else 
       { PlayerN1DTO objRes = new PlayerN1DTO(winnerPlayer.getId(),winnerPlayer.getNom(),winnerPlayer.getDataRegistre(), 
                                              mTiradesDAO.calcSuccessPercent(winnerPlayer.getId()));
         return ResponseEntity.ok(objRes); 
       }         
  }
  
 
}
