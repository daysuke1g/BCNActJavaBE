package zm16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@SpringBootApplication
public class SpringM16TaskApplication          
{ 
  public static void main(String[] args) 
  { SpringApplication.run(SpringM16TaskApplication.class, args);
  }

  @EnableWebSecurity  
  @Configuration
  class WebSecurityConfig extends WebSecurityConfigurerAdapter
  { @Override
    protected void configure(HttpSecurity http) throws Exception 
    { http.csrf().disable()
          .formLogin().disable()  
          .logout().disable()
          .addFilterAfter(new zm16.security.JWTAuthorizationFilter(),UsernamePasswordAuthenticationFilter.class)
          .authorizeRequests()  
          //No restringir acces a la pagina principal 
          .antMatchers(HttpMethod.GET,"/index.html").permitAll()
          .antMatchers(HttpMethod.GET,"/css/**").permitAll()
          .antMatchers(HttpMethod.GET,"/scripts/**").permitAll()
          // No restringir acces al nivell 1 fase1
          .antMatchers(HttpMethod.GET,"/n1f1players/**").permitAll()
          .antMatchers(HttpMethod.POST,"/n1f1players/**").permitAll()
          .antMatchers(HttpMethod.PUT,"/n1f1players/**").permitAll()
          .antMatchers(HttpMethod.DELETE,"/n1f1players/**").permitAll()
          .antMatchers(HttpMethod.OPTIONS,"/n1f1players/**").permitAll()
          .antMatchers(HttpMethod.HEAD,"/n1f1players/**").permitAll()
          //No restringir acces al nivell 1 fase2
          .antMatchers(HttpMethod.GET,"/n1f2players/**").permitAll()
          .antMatchers(HttpMethod.POST,"/n1f2players/**").permitAll()
          .antMatchers(HttpMethod.PUT,"/n1f2players/**").permitAll()
          .antMatchers(HttpMethod.DELETE,"/n1f2players/**").permitAll()
          .antMatchers(HttpMethod.OPTIONS,"/n1f2players/**").permitAll()
          .antMatchers(HttpMethod.HEAD,"/n1f2players/**").permitAll()
          //Restringir acc�s al nivell 1 fase3
          .antMatchers(HttpMethod.POST,"/n1f3players/users").permitAll()
          //No restringir acces al nivell 2
          .antMatchers(HttpMethod.GET,"/n2players/**").permitAll()
          .antMatchers(HttpMethod.POST,"/n2players/**").permitAll()
          .antMatchers(HttpMethod.PUT,"/n2players/**").permitAll()
          .antMatchers(HttpMethod.DELETE,"/n2players/**").permitAll()
          .antMatchers(HttpMethod.OPTIONS,"/n2players/**").permitAll()
          .antMatchers(HttpMethod.HEAD,"/n2players/**").permitAll()
          
          .anyRequest().authenticated();
    }
  }  
  
}
