package zm16.dao;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

import zm16.model.PlayerN1F2;

public interface PlayersN1F2DAO extends MongoRepository<PlayerN1F2,Long>
{ 
  //https://docs.spring.io/spring-data/mongodb/docs/1.2.0.RELEASE/reference/html/mongo.repositories.html
  //https://docs.spring.io/spring-data/mongodb/docs/current/reference/html/#mongodb.repositories.queries.json-based
  //https://www.baeldung.com/queries-in-spring-data-mongodb
  
  //Buscar el primera registre per nom  
  public PlayerN1F2 findFirst1ByNom(String nom);   
  
  //Maxim _id mapejat al @id
  @Aggregation(pipeline="{ '$group' : { '_id' : 0, 'x' : { $max: '$_id' } } }") 
  public int getMaxId(); 

  //Buscar el primera registre per nom  
  public PlayerN1F2 findFirst1ByNomAndIdNot(String nom,Long pId); 

 
}



/*
@Query(value="{}",sort="{'_id':1}")
public List<Object> getAll();  

Lista de Ids
@Query(value="{}",fields="{'_id':1}",sort="{'_id':-1}")
public List<Object> getMaxId();  
 // https://blog.marcnuri.com/spring-data-mongodb-implementacion-de-un-repositorio-a-medida
// https://docs.spring.io/spring-data/mongodb/docs/1.2.0.RELEASE/reference/html/mapping-chapter.html

*/

