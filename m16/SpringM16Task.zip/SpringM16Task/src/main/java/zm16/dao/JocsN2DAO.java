package zm16.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import zm16.model.JocN2;

public interface JocsN2DAO extends JpaRepository<JocN2,Long>
{ 
  //Buscar pel nom  
  public JocN2 findFirst1ByNom(String nom); 
    
}

