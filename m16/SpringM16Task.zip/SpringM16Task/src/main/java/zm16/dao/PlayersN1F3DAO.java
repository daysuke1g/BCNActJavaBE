package zm16.dao;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;

import zm16.model.PlayerN1F3;

public interface PlayersN1F3DAO extends JpaRepository<PlayerN1F3,Long>
{ 
  // https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#reference
  // https://www.baeldung.com/spring-data-jpa-modifying-annotation
  
  
  //Buscar el primera registre per nom  
  public PlayerN1F3 findFirst1ByNom(String nom); 
  
  
  //Buscar el primera registre per nom  
  public PlayerN1F3 findFirst1ByNomAndIdNot(String nom,Long pId); 
  
  
  //Primer jugador sense tirades
  @Query(nativeQuery=true,value="select j.* from jugadorsn1 j where (select count(*) from tiradesn1 t where t.jugador_id=j.id)=0 limit 1")
  public PlayerN1F3 getPrimSenseTirades();
  
  //Jugador amb menor % d'exit   
  @Query(nativeQuery=true,value="select *"+
                                 " from (select t1.jugador_id,round((sum(case when (dau1+dau2)=7 then 1 else 0 end)/(select count(*) from tiradesn1 t2 where t2.jugador_id = t1.jugador_id))*100,2) tpc_exit"+
                                        " from tiradesn1 t1"+
                                       " group by 1"+
                                       " order by 2 asc"+
                                       " limit 1) as it1 LEFT JOIN jugadorsn1 ON (it1.jugador_id = jugadorsn1.id)")
  public PlayerN1F3 getPlayerMinTPC();
  
  
  //Jugador amb major % d'exit 
  @Query(nativeQuery=true,value="select *"+
      " from (select t1.jugador_id,round((sum(case when (dau1+dau2)=7 then 1 else 0 end)/(select count(*) from tiradesn1 t2 where t2.jugador_id = t1.jugador_id))*100,2) tpc_exit"+
             " from tiradesn1 t1"+
            " group by 1"+
            " order by 2 desc"+
            " limit 1) as it1 LEFT JOIN jugadorsn1 ON (it1.jugador_id = jugadorsn1.id)")
  public PlayerN1F3 getPlayerMaxTCP();
  
  
}

