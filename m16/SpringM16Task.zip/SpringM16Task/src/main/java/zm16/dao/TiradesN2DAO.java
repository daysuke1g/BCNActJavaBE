package zm16.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import zm16.model.PlayerN2;
import zm16.model.TiradaN2;

public interface TiradesN2DAO extends JpaRepository<TiradaN2,UUID> 
{
  @Query(nativeQuery=true,
         value="select case when (select count(*) from tiradesn2 where tiradesn2.jugador_id = t1.jugador_id) > 0 then "+
                               " round((sum(case when (dau1+dau2)=7 then 1 else 0 end)/(select count(*) from tiradesn2 t2 where t2.jugador_id = t1.jugador_id))*100,2)"+             
                           "else round(0,2) end " +
                " from tiradesn2 t1"+
              " where t1.jugador_id = ?1")  
  public float calcSuccessPercent(String pCodJugador); // Al ser una query nativa cambiar de UUID a String

  //Buscar el primera registre per nom   
  public List<TiradaN2> findByPlayer(PlayerN2 p); 
  
  @Query("SELECT t FROM TiradaN2 t INNER JOIN PlayerN2 p ON p.id = t.player WHERE p.id = ?1 ")
  public List<TiradaN2> findByJugador(UUID id); 
  
  public int countByPlayer(PlayerN2 player);
  public int deleteByPlayer(PlayerN2 player);
  
}





