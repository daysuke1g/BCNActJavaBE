package zm16.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import zm16.model.PlayerN1;
import zm16.model.TiradaN1;

public interface TiradesN1DAO extends JpaRepository<TiradaN1,Long> 
{
  @Query(nativeQuery=true,value="select case when (select count(*) from tiradesn1 where tiradesn1.jugador_id = t1.jugador_id) > 0 then "+
                                                 " round((sum(case when (dau1+dau2)=7 then 1 else 0 end)/(select count(*) from tiradesn1 t2 where t2.jugador_id = t1.jugador_id))*100,2)"+
                                            "else round(0,2) end " +
                                 " from tiradesn1 t1"+
                                " where t1.jugador_id = ?1")
  public float calcSuccessPercent(long pCodJugador); 

  //Buscar el primera registre per nom   
  public List<TiradaN1> findByPlayer(PlayerN1 p); 
  
  @Query("SELECT t FROM TiradaN1 t INNER JOIN PlayerN1 p ON p.id = t.player WHERE p.id = ?1 ")
  public List<TiradaN1> findByJugador(Long id); 
  
  public int countByPlayer(PlayerN1 player);
  public int deleteByPlayer(PlayerN1 player);
  
}





