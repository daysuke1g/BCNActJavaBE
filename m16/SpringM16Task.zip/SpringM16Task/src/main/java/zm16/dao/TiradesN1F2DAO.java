package zm16.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

import zm16.model.TiradaN1F2;

public interface TiradesN1F2DAO extends MongoRepository<TiradaN1F2,Long> 
{
  //Maxim _id mapejat al @id
  @Aggregation(pipeline="{ '$group' : { '_id' : 0, 'x' : { $max: '$_id' } } }") 
  public int getMaxId();  
  

  //Buscar tirades per jugador  
  public List<TiradaN1F2> findByJugador(long jugador);
   
  //Nombre de tirades per a un jugador
  public int countByJugador(long jugador);
  
  //Esborrar les tirades d'un jugador 
  public int deleteByJugador(long jugador);
    
  
}

//..... 
//"{ '$project' : { '_id': 1, 'dau1': 1, 'dau1': 1 } } " + 
// "{ '$sort' : { '_id': -1 } } "+
//@Aggregation(pipeline= "{ $project : { _id: 1 } } "+
//                      "")

// , value=\"{ 'firstname' : ?0 }

//@Query(fields="{ 'id' : 1, 'dau1' : 1, 'dau2': 1}",sort="{'id': 1 }") 
//public List<Object> getAllId(); 

/*
 * https://docs.mongodb.com/manual/core/aggregation-pipeline/
https://stackoverflow.com/questions/66766935/how-to-return-list-of-specific-fields-in-query-java-spring-mongo-repository
https://www.javaprogramto.com/2020/05/spring-boot-data-mongodb-projections-aggregations.html

 
@Query(nativeQuery=true,value="select case when (select count(*) from tiradesn1 where tiradesn1.jugador_id = t1.jugador_id) > 0 then "+
                                               " round((sum(case when (dau1+dau2)=7 then 1 else 0 end)/(select count(*) from tiradesn1 t2 where t2.jugador_id = t1.jugador_id))*100,2)"+
                                          "else round(0,2) end " +
                               " from tiradesn1 t1"+
                              " where t1.jugador_id = ?1")
public float calcSuccessPercent(long pCodJugador); 

//Buscar el primera registre per nom   
public List<TiradaN1> findByPlayer(PlayerN1 p); 

@Query("SELECT t FROM TiradaN1 t INNER JOIN PlayerN1 p ON p.id = t.player WHERE p.id = ?1 ")
public List<TiradaN1> findByJugador(Long id); 


*/



